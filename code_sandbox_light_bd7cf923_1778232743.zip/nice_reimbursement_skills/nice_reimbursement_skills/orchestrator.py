"""
End-to-end pipeline that wires the 7 skills together.

Mirrors the workflow described in the explainable-landscape template:

    1. Analogue identification           (Skill 0)
    >>> MANDATORY USER CONFIRMATION GATE <<<
    2. NICE history retrieval & PDFs     (Skill 1)
    3. Per-analogue NICE analysis        (Skill 2, run for each confirmed analogue)
    4. Cross-analogue comparison         (Skill 3)
    5. Base-case prediction              (Skill 4)
    6. Evidence recommendations          (Skill 5)
    7. Improved-evidence prediction      (Skill 6)

The pipeline returns a `FullAssessmentOutput` containing every artefact, the
audit trail, and the assumption/uncertainty logs that the explainable-landscape
template requires.
"""
from __future__ import annotations

import logging
from datetime import datetime
from typing import Callable, Iterable, List, Optional

from .llm_client import LLMClient
from .models import (
    AnalogueIdentificationInput,
    AnalogueIdentificationOutput,
    AnalogueRef,
    CommercialAssumptions,
    CompareAllAnaloguesInput,
    CompareAllAnaloguesOutput,
    FullAssessmentOutput,
    NICEHistoryRetrievalInput,
    NICEHistoryRetrievalOutput,
    PredictCurrentEvidenceInput,
    PredictWithAdditionalEvidenceInput,
    ProductA,
    ProductACurrentEvidence,
    ProposedAnalogue,
    RecommendAdditionalEvidenceInput,
    AnalyzeOneAnalogueInput,
    AnalogueProfile,
)
from .skills import (
    AnalogueIdentificationSkill,
    AnalyzeOneAnalogueSkill,
    CompareAllAnaloguesSkill,
    NICEHistoryRetrievalSkill,
    PredictCurrentEvidenceSkill,
    PredictWithAdditionalEvidenceSkill,
    RecommendAdditionalEvidenceSkill,
)

logger = logging.getLogger(__name__)


#: Type alias: a confirmation callback receives the proposed analogue list and
#: returns the user-confirmed list (possibly edited / re-ranked).
ConfirmationCallback = Callable[[AnalogueIdentificationOutput], List[ProposedAnalogue]]


def auto_confirm_all(proposal: AnalogueIdentificationOutput) -> List[ProposedAnalogue]:
    """Default callback: include every analogue whose default status is 'included'."""
    return [a for a in proposal.proposed_analogues if a.inclusion_status_default == "included"]


def _proposal_to_analogue_refs(items: Iterable[ProposedAnalogue]) -> List[AnalogueRef]:
    return [
        AnalogueRef(
            name=p.name,
            brand_name=p.brand_name,
            indication=None,  # filled by NICE retrieval if present in title
            line_of_therapy=None,
        )
        for p in items
    ]


class ReimbursementAssessmentPipeline:
    """Run the full 7-skill workflow."""

    def __init__(
        self,
        llm_client: LLMClient,
        download_dir: str = "./nice_documents",
        max_documents_per_analogue: Optional[int] = 25,
    ):
        self.llm_client = llm_client
        self.download_dir = download_dir
        self.max_docs = max_documents_per_analogue

        # Instantiate (these instances override the default ones in the global
        # registry that have no LLM client attached).
        self.analogue_identifier = AnalogueIdentificationSkill(llm_client=llm_client)
        self.nice_retriever = NICEHistoryRetrievalSkill()
        self.one_analyzer = AnalyzeOneAnalogueSkill(llm_client=llm_client)
        self.comparator = CompareAllAnaloguesSkill(llm_client=llm_client)
        self.base_predictor = PredictCurrentEvidenceSkill(llm_client=llm_client)
        self.evidence_recommender = RecommendAdditionalEvidenceSkill(llm_client=llm_client)
        self.improved_predictor = PredictWithAdditionalEvidenceSkill(llm_client=llm_client)

    # ------------------------------------------------------------------ #

    def run(
        self,
        product_a: ProductA,
        current_evidence: ProductACurrentEvidence,
        commercial_assumptions: Optional[CommercialAssumptions] = None,
        on_confirm: ConfirmationCallback = auto_confirm_all,
        max_competitors: int = 6,
        max_analogues: int = 8,
        extra_context: Optional[str] = None,
        download_pdfs: bool = True,
    ) -> FullAssessmentOutput:
        commercial_assumptions = commercial_assumptions or CommercialAssumptions()
        audit: dict = {"started_at": datetime.utcnow().isoformat()}

        # 1. Analogue identification ---------------------------------------
        logger.info("Step 1/7 — analogue identification")
        proposal = self.analogue_identifier(
            AnalogueIdentificationInput(
                product_a=product_a,
                max_competitors=max_competitors,
                max_analogues=max_analogues,
                extra_context=extra_context,
            )
        )
        audit["step1_proposed_count"] = len(proposal.proposed_analogues)

        # >>> MANDATORY USER CONFIRMATION GATE <<<
        confirmed = on_confirm(proposal)
        if not confirmed:
            raise RuntimeError(
                "User confirmation returned an empty analogue list. Aborting."
            )
        audit["step1_confirmed_count"] = len(confirmed)

        # 2. NICE retrieval ------------------------------------------------
        logger.info("Step 2/7 — NICE history retrieval (%s analogues)", len(confirmed))
        retrieval = self.nice_retriever(
            NICEHistoryRetrievalInput(
                analogues=_proposal_to_analogue_refs(confirmed),
                download_dir=self.download_dir,
                download_pdfs=download_pdfs,
                max_documents_per_analogue=self.max_docs,
            )
        )
        audit["step2_pdfs_downloaded"] = retrieval.pdfs_downloaded

        # 3. Per-analogue analysis ----------------------------------------
        logger.info("Step 3/7 — analyse each analogue")
        profiles: List[AnalogueProfile] = []
        for guidance in retrieval.guidance_records:
            docs_for_analogue = [
                d for d in retrieval.documents
                if d.analogue_name == guidance.analogue_name
            ]
            try:
                profile_out = self.one_analyzer(
                    AnalyzeOneAnalogueInput(
                        analogue_name=guidance.analogue_name,
                        guidance_code=guidance.nice_guidance_code,
                        documents=docs_for_analogue,
                    )
                )
                profiles.append(profile_out.profile)
            except Exception as e:
                logger.warning("Logic 1 failed for %s: %s", guidance.analogue_name, e)

        # 4. Cross-analogue comparison ------------------------------------
        comparison: Optional[CompareAllAnaloguesOutput] = None
        if profiles:
            logger.info("Step 4/7 — comparison across %s profiles", len(profiles))
            comparison = self.comparator(
                CompareAllAnaloguesInput(product_a=product_a, profiles=profiles)
            )

        # 5. Base-case prediction -----------------------------------------
        base_pred = None
        if comparison is not None:
            logger.info("Step 5/7 — base-case prediction (current evidence)")
            base_pred = self.base_predictor(
                PredictCurrentEvidenceInput(
                    product_a=product_a,
                    current_evidence=current_evidence,
                    comparison=comparison,
                    commercial_assumptions=commercial_assumptions,
                )
            )

        # 6. Evidence recommendations -------------------------------------
        evidence = None
        if base_pred is not None and comparison is not None:
            logger.info("Step 6/7 — evidence recommendations")
            evidence = self.evidence_recommender(
                RecommendAdditionalEvidenceInput(
                    product_a=product_a,
                    base_prediction=base_pred,
                    comparison=comparison,
                )
            )

        # 7. Improved-evidence prediction ---------------------------------
        improved = None
        if base_pred is not None and evidence is not None and comparison is not None:
            logger.info("Step 7/7 — improved-evidence prediction")
            improved = self.improved_predictor(
                PredictWithAdditionalEvidenceInput(
                    base_prediction=base_pred,
                    evidence_recommendations=evidence,
                    comparison=comparison,
                    commercial_assumptions=commercial_assumptions,
                )
            )

        audit["finished_at"] = datetime.utcnow().isoformat()

        return FullAssessmentOutput(
            product_a=product_a,
            analogue_identification=proposal,
            nice_retrieval=retrieval,
            analogue_profiles=profiles,
            comparison=comparison,
            base_case_prediction=base_pred,
            evidence_recommendations=evidence,
            improved_prediction=improved,
            audit_trail=audit,
        )
