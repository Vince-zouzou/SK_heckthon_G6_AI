"""
LLM client abstraction.

The skill library uses LLMs for the parts of each logic that genuinely require
reasoning (e.g. extracting NICE decision domains from a committee paper,
classifying analogues into 'recommended / restricted / managed access /
not recommended' precedents).

A skill never imports `openai` or `anthropic` directly. It calls
`self.llm_client.complete(prompt, response_format='json')`.
This file provides:

    * `LLMClient`      — abstract base
    * `OpenAIClient`   — wraps openai>=1.40 (uses `responses` or `chat.completions`)
    * `AnthropicClient` — wraps anthropic>=0.34
    * `EchoClient`     — deterministic dummy useful for unit tests

`json_complete()` always returns a parsed dict, retrying on bad JSON.
"""
from __future__ import annotations

import json
import logging
import os
import re
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional

from tenacity import retry, stop_after_attempt, wait_exponential

logger = logging.getLogger(__name__)


class LLMClient(ABC):
    """Abstract LLM client used by every skill."""

    DEFAULT_SYSTEM = (
        "You are a senior UK market-access and NICE HTA analyst. "
        "Answer with strict adherence to the requested JSON schema. "
        "Never invent NICE decisions, ICERs, or PAS values that are not in the "
        "supplied source text. When information is not available, return null "
        "and add a short note in the `notes` field."
    )

    def __init__(self, model: str, temperature: float = 0.1, max_tokens: int = 4096):
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens

    # ----------------- public API ---------------------------------------- #

    @abstractmethod
    def complete(self, prompt: str, system: Optional[str] = None) -> str:
        """Plain-text completion."""

    def json_complete(
        self,
        prompt: str,
        system: Optional[str] = None,
        max_attempts: int = 3,
    ) -> Dict[str, Any]:
        """
        Force the model to return a parseable JSON object.

        Strategy: ask explicitly, then attempt to extract the first {...} block.
        Retries up to `max_attempts` if parsing fails.
        """
        sys_msg = system or self.DEFAULT_SYSTEM
        last_err: Optional[Exception] = None
        for attempt in range(1, max_attempts + 1):
            response = self.complete(prompt, system=sys_msg)
            try:
                return _extract_json(response)
            except Exception as e:
                last_err = e
                logger.warning("LLM JSON parse attempt %s failed: %s", attempt, e)
                prompt = (
                    prompt
                    + "\n\nIMPORTANT: Your previous response was not valid JSON. "
                    "Return ONLY a JSON object, no prose, no markdown fences."
                )
        raise ValueError(f"LLM did not return valid JSON after {max_attempts} attempts: {last_err}")


def _extract_json(text: str) -> Dict[str, Any]:
    """Best-effort JSON extraction from an LLM response."""
    text = text.strip()
    # Strip markdown fences
    text = re.sub(r"^```(?:json)?\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    # Try to find the first balanced {...} block.
    start = text.find("{")
    if start == -1:
        raise ValueError("No JSON object in response.")
    depth = 0
    for i in range(start, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return json.loads(text[start : i + 1])
    raise ValueError("Unbalanced JSON object in response.")


# ---------------------------------------------------------------------- #
# OpenAI                                                                 #
# ---------------------------------------------------------------------- #

class OpenAIClient(LLMClient):
    def __init__(
        self,
        model: str = "gpt-4o-mini",
        api_key: Optional[str] = None,
        temperature: float = 0.1,
        max_tokens: int = 4096,
    ):
        super().__init__(model=model, temperature=temperature, max_tokens=max_tokens)
        try:
            from openai import OpenAI
        except ImportError as e:  # pragma: no cover
            raise ImportError("Install openai: pip install openai") from e
        self._client = OpenAI(api_key=api_key or os.environ.get("OPENAI_API_KEY"))

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(min=1, max=10))
    def complete(self, prompt: str, system: Optional[str] = None) -> str:
        resp = self._client.chat.completions.create(
            model=self.model,
            temperature=self.temperature,
            max_tokens=self.max_tokens,
            messages=[
                {"role": "system", "content": system or self.DEFAULT_SYSTEM},
                {"role": "user", "content": prompt},
            ],
        )
        return resp.choices[0].message.content or ""


# ---------------------------------------------------------------------- #
# Anthropic                                                              #
# ---------------------------------------------------------------------- #

class AnthropicClient(LLMClient):
    def __init__(
        self,
        model: str = "claude-3-5-sonnet-20241022",
        api_key: Optional[str] = None,
        temperature: float = 0.1,
        max_tokens: int = 4096,
    ):
        super().__init__(model=model, temperature=temperature, max_tokens=max_tokens)
        try:
            import anthropic
        except ImportError as e:  # pragma: no cover
            raise ImportError("Install anthropic: pip install anthropic") from e
        self._client = anthropic.Anthropic(api_key=api_key or os.environ.get("ANTHROPIC_API_KEY"))

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(min=1, max=10))
    def complete(self, prompt: str, system: Optional[str] = None) -> str:
        resp = self._client.messages.create(
            model=self.model,
            max_tokens=self.max_tokens,
            temperature=self.temperature,
            system=system or self.DEFAULT_SYSTEM,
            messages=[{"role": "user", "content": prompt}],
        )
        # Concatenate all text blocks
        parts: List[str] = []
        for block in resp.content:
            if getattr(block, "type", None) == "text":
                parts.append(block.text)
        return "".join(parts)


# ---------------------------------------------------------------------- #
# Echo (test fixture)                                                    #
# ---------------------------------------------------------------------- #

class EchoClient(LLMClient):
    """Returns canned JSON. Useful for unit tests / dry runs without a key."""

    def __init__(self, canned: Optional[Dict[str, Any]] = None):
        super().__init__(model="echo")
        self.canned = canned or {}

    def complete(self, prompt: str, system: Optional[str] = None) -> str:
        return json.dumps(self.canned)
