"""
Simple CLI entrypoint.

Usage:
    nice-skills run --input product_a.json --provider openai --model gpt-4o
    nice-skills schemas openai > tools.json
    nice-skills list
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path

from . import (
    AnalogueIdentificationSkill,
    AnthropicClient,
    OpenAIClient,
    ReimbursementAssessmentPipeline,
    registry,
)
from .models import (
    CommercialAssumptions,
    ProductA,
    ProductACurrentEvidence,
)


def _build_client(provider: str, model: str | None):
    if provider == "openai":
        return OpenAIClient(model=model or "gpt-4o-mini")
    if provider == "anthropic":
        return AnthropicClient(model=model or "claude-3-5-sonnet-20241022")
    raise ValueError(f"Unknown provider: {provider}")


def cmd_run(args) -> int:
    payload = json.loads(Path(args.input).read_text(encoding="utf-8"))
    product_a = ProductA.model_validate(payload["product_a"])
    current_evidence = ProductACurrentEvidence.model_validate(
        payload.get("current_evidence", {})
    )
    commercial = CommercialAssumptions.model_validate(
        payload.get("commercial_assumptions", {})
    )

    client = _build_client(args.provider, args.model)
    pipeline = ReimbursementAssessmentPipeline(
        llm_client=client,
        download_dir=args.download_dir,
        max_documents_per_analogue=args.max_docs,
    )
    result = pipeline.run(
        product_a=product_a,
        current_evidence=current_evidence,
        commercial_assumptions=commercial,
        max_competitors=args.max_competitors,
        max_analogues=args.max_analogues,
        download_pdfs=not args.no_download,
    )
    Path(args.output).write_text(
        result.model_dump_json(indent=2), encoding="utf-8"
    )
    print(f"Saved full assessment to {args.output}")
    return 0


def cmd_schemas(args) -> int:
    if args.framework == "openai":
        out = registry.openai_tools()
    elif args.framework == "anthropic":
        out = registry.anthropic_tools()
    elif args.framework == "json":
        out = {s.name: s.input_json_schema() for s in (registry.get(n) for n in registry.list())}
    else:
        raise ValueError(args.framework)
    json.dump(out, sys.stdout, indent=2, default=str)
    sys.stdout.write("\n")
    return 0


def cmd_list(_args) -> int:
    for name in registry.list():
        skill = registry.get(name)
        print(f"{name:40s} {skill.description.splitlines()[0]}")
    return 0


def main(argv: list[str] | None = None) -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    p = argparse.ArgumentParser("nice-skills")
    sub = p.add_subparsers(dest="command", required=True)

    p_run = sub.add_parser("run", help="Run the full assessment pipeline")
    p_run.add_argument("--input", required=True, help="Path to a JSON file with product_a + current_evidence")
    p_run.add_argument("--output", default="full_assessment.json")
    p_run.add_argument("--provider", choices=["openai", "anthropic"], default="openai")
    p_run.add_argument("--model", default=None)
    p_run.add_argument("--download-dir", default="./nice_documents")
    p_run.add_argument("--max-competitors", type=int, default=6)
    p_run.add_argument("--max-analogues", type=int, default=8)
    p_run.add_argument("--max-docs", type=int, default=25)
    p_run.add_argument("--no-download", action="store_true")
    p_run.set_defaults(func=cmd_run)

    p_sc = sub.add_parser("schemas", help="Print tool schemas")
    p_sc.add_argument("framework", choices=["openai", "anthropic", "json"])
    p_sc.set_defaults(func=cmd_schemas)

    p_ls = sub.add_parser("list", help="List registered skills")
    p_ls.set_defaults(func=cmd_list)

    args = p.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
