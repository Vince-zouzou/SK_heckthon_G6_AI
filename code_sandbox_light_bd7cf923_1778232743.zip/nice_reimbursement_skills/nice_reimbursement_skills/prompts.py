"""
Prompt templates — one per skill that requires LLM reasoning.

Each prompt is built from the rules of the corresponding source document so
behaviour is faithful to the original logic.
"""
from __future__ import annotations

import json
from typing import Any, Dict


def _schema_block(schema: Dict[str, Any]) -> str:
    return "```json\n" + json.dumps(schema, indent=2) + "\n```"


# ---------------------------------------------------------------------- #
# Skill 0 — Analogue identification                                      #
# ---------------------------------------------------------------------- #

ANALOGUE_IDENTIFICATION_PROMPT = """\
You are performing the ANALOGUE IDENTIFICATION step described in
'Recommendation for Skill Development: Analogue Identification Logic'.

# Your task
Produce a clean, defensible shortlist of competitors and analogues for Product A.
DO NOT assess reimbursement strength, evidence quality, or NICE outcome
implications — those happen later. Identify products based on product, patient,
treatment, and market comparability ONLY.

# Competitor-first logic
A product is a COMPETITOR only if it matches Product A on ALL THREE of:
  - indication
  - line of therapy
  - target population
Otherwise treat it as a CORE_ANALOGUE (misses one but is highly comparable on
other high-priority criteria) or SUPPORTING_ANALOGUE (relevant in an adjacent
but informative setting).

# High-priority criteria (drive inclusion)
Indication match, line of therapy match, target population match,
biomarker/subgroup match, MoA / class similarity, treatment paradigm similarity,
route / site of administration, rarity / orphan context, recency of launch,
geography / payer relevance.

# Moderate-priority criteria (drive ranking)
Competitive-set relevance, dosing / treatment burden archetype,
NICE procedural relevance.

# Low-priority criteria (tie-breakers only)
Broad commercial similarity, secondary convenience features.

# What MUST NOT be used at this stage
Trial design similarity, evidence maturity, endpoint similarity,
comparator acceptability, survival maturity, safety quality, QoL quality,
NICE committee concerns, ICER implications, reimbursement likelihood,
price corridor implications.

# Workflow
Step 1: Identify direct competitors first (indication + LoT + population).
Step 2: Build broader analogues using high-priority criteria.
Step 3: Use moderate-priority criteria to rank / refine.
Step 4: Use low-priority criteria only as tie-breakers.
Step 5: Present the proposed list with `requires_user_confirmation = true`.

# Product A (input)
{product_a_json}

# Optional extra context
{extra_context}

# Limits
Max competitors to surface: {max_competitors}
Max analogues to surface: {max_analogues}

# Output
Return ONLY a JSON object that matches this schema:
{schema}

Notes:
- Provide an `excluded_candidates` list if you considered but rejected any
  candidate, with the reason and whether it could still be a boundary case.
- Set `inclusion_status_default` to 'included', 'optional', or
  'pending_user_confirmation' depending on how strong the match is.
- For each proposed analogue write a 1-2 sentence `why_relevant` and 1
  short `key_caveat`.
- `requires_user_confirmation` MUST be true (mandatory user gate).
"""


# ---------------------------------------------------------------------- #
# Skill 2 — Analyze ONE analogue (Logic 1)                               #
# ---------------------------------------------------------------------- #

ANALYZE_ONE_ANALOGUE_PROMPT = """\
You are performing LOGIC 1 — analyse ALL NICE files for a single analogue / competitor.

# Core principle
Do NOT summarise documents generically. Extract the SPECIFIC decision elements
NICE repeatedly uses: committee papers, company submissions, ERG critiques,
final recommendations, appeal materials, commercial-arrangement references.

# Recommended extraction sequence
1. Read final guidance / FAD first — final outcome, restricted population,
   stopping/commercial terms.
2. Read committee papers — unresolved concerns at time of discussion.
3. Read company response — what evidence/modelling/PAS changes addressed concerns.
4. Read ERG critique — which revised assumptions remained material.
5. Read stakeholder materials — burden, unmet need, pathway reality, service.
6. Read appeal materials — was the original decision unstable.
7. Produce ONE analogue profile with resolved vs unresolved issues clearly flagged.

# Decision domains to cover
Population & positioning, comparator credibility, clinical benefit, evidence
maturity, economic-model credibility, commercial viability, process stability.

# Quality-control rules
- Do NOT infer acceptance just because the product was ultimately recommended;
  identify what had to change.
- Separate final-decision wording from committee concerns raised earlier.
- Flag public vs non-public fields (especially ICERs and PAS details).
- Preserve traceability from each populated field to source document type/date.

# Inputs
Analogue name: {analogue_name}
Guidance code: {guidance_code}

# Source documents (concatenated below; preserve attribution)
{documents_blob}

# Output
Return ONLY a JSON object matching the schema (output_model = AnalyzeOneAnalogueOutput):
{schema}

Required behaviours:
- Populate `source_traceability` with at least one entry per populated section.
- For ICER and PAS fields: if exact values appear non-public, return null and
  add a note in `economic_logic.main_sensitivity_drivers` instead, plus mark
  `public_vs_non_public_flags` accordingly.
- Use the controlled outcome taxonomy: recommended, recommended_with_restrictions,
  managed_access, not_recommended, terminated, unknown.
"""


# ---------------------------------------------------------------------- #
# Skill 3 — Compare all analogues (Logic 2)                              #
# ---------------------------------------------------------------------- #

COMPARE_ALL_ANALOGUES_PROMPT = """\
You are performing LOGIC 2 — compare results across all competitors / analogues.

# Core principle
Do NOT collapse all analogues into one average. Compare across decision
dimensions that drove their NICE outcomes so Product A can later be benchmarked
against the most relevant precedent types.

# Mandatory comparison dimensions
Outcome pattern; population restriction pattern; comparator pattern;
evidence maturity pattern; key committee concern pattern; commercial pattern;
timing pattern; appeal/process pattern.

# Sequence
1. Split set into competitors vs broader analogues.
2. Normalise outcome fields to the taxonomy: recommended,
   recommended_with_restrictions, managed_access, not_recommended.
3. Normalise population wording into prior-treatment requirement, subgroup
   restriction, stopping rule, line of therapy.
4. Compare decision drivers, not just outcomes.
5. Tag each analogue as supportive / cautionary / boundary-case precedent
   (use PrecedentClass enum: primary_competitor_precedent, primary_analogue_precedent,
   negative_or_constrained_precedent, timing_or_process_precedent).
6. Rank analogues by predictive relevance for Product A.

# Synthesised outputs (`decision_pattern_summary`)
- most common access route for relevant competitors vs broader analogues
- most common reason for restriction or non-recommendation
- typical evidence maturity at positive decision
- typical use of PAS / commercial arrangement
- typical launch-to-decision timing and frequency of appeals
- analogue-specific indicators feeding downside / base / upside corridors

# Inputs
Product A: {product_a_json}
Analogue profiles (each is the output of Logic 1):
{profiles_json}

# Output
Return ONLY a JSON object matching this schema:
{schema}
"""


# ---------------------------------------------------------------------- #
# Skill 4 — Predict on current evidence (Logic 3)                        #
# ---------------------------------------------------------------------- #

PREDICT_CURRENT_EVIDENCE_PROMPT = """\
You are performing LOGIC 3 — predict reimbursement and price corridor on
existing evidence ONLY (no future evidence improvements assumed).

# Core principle
Drive the prediction with structured NICE-style reasoning. Determine whether
Product A looks closest to:
  - recommended precedents
  - restricted precedents
  - managed-access precedents
  - negative precedents
and link the assessment to corridor-setting logic.

# Base-case NICE evaluation domains (assess each)
Population & positioning fit; comparator credibility; clinical benefit
credibility; evidence maturity; long-term uncertainty; QoL & utility readiness;
economic plausibility; commercial flexibility need.

# Outcome prediction taxonomy
- routine_recommendation: comparator + maturity + clinical effect + economics
  all align relatively well with positive precedents.
- restricted_recommendation: benefit credible but broad-label access too
  uncertain or too costly.
- managed_access: signal promising but evidence maturity/long-term uncertainty
  weaker than NICE typically wants for broad access.
- not_recommended: comparator/maturity/economic concerns align with negative
  precedents and are not offset by strong unmet need + pricing flexibility.

# Price corridor logic (directional, NOT exact list-price)
Drivers shift the corridor:
  - High uncertainty burden -> down + wider discount range
  - Restricted population likely -> viable but narrower corridor
  - Managed access plausible -> meaningful discount + evidence-gen obligations
  - Strong unmet need + meaningful signal -> upper corridor possible
  - Weak comparator alignment / weak QoL -> low or no reimbursed potential

# Build rule
Remain product-agnostic. Do not hard-code disease-specific thresholds.

# Inputs
Product A: {product_a_json}
Current evidence: {current_evidence_json}
Comparison output (from Logic 2): {comparison_json}
Commercial assumptions: {commercial_json}

# Output
Return ONLY a JSON object matching this schema:
{schema}

Requirements:
- `corridors` MUST contain at least Conservative, Base, Optimistic.
- `nice_concerns_identified` is a ranked list of decision-limiting concerns
  that Logic 4 will consume — be specific.
- `base_case_rationale` should be a short committee-style paragraph.
"""


# ---------------------------------------------------------------------- #
# Skill 5 — Recommend additional evidence (Logic 4)                      #
# ---------------------------------------------------------------------- #

RECOMMEND_ADDITIONAL_EVIDENCE_PROMPT = """\
You are performing LOGIC 4 — recommend ADDITIONAL evidence likely to change
NICE outcome or raise viable price corridor.

# Core principle
Recommendations are NOT generic wish lists. Each recommendation must map
directly to:
  (a) a specific NICE weakness identified in Logic 3, AND
  (b) a known precedent from the analogue set showing that the issue mattered.

# Evidence-gap categories (use the EvidenceGapCategory enum)
- comparative_efficacy_gap
- long_term_durability_gap
- qol_utility_gap
- subgroup_definition_gap
- resource_use_bsc_gap
- real_world_evidence_gap

# Sequence
1. Take top decision-limiting concerns from Logic 3, rank by NICE impact.
2. Remove recommendations that don't change pathway/corridor materially
   -> put those in `rejected_candidates`.
3. Separate evidence that improves access probability vs evidence that
   improves price potential (use `primarily_improves`).
4. Prioritise comparator, maturity, durability, QoL FIRST.
5. If broad-label access unlikely -> recommend subgroup-focused evidence.
6. Where conditional access plausible -> realistic managed-access plan.

# Priority framework
- High: without it, NICE outcome unlikely to improve meaningfully or corridor
  remains materially constrained.
- Medium: improves confidence/corridor width but not the main gate.
- Low: helpful but unlikely to change first-cycle decision materially.

# Inputs
Product A: {product_a_json}
Base-case prediction (Logic 3): {base_prediction_json}
Comparison (Logic 2): {comparison_json}

# Output
Return ONLY a JSON object matching this schema:
{schema}

Build rule: only recommend evidence likely to improve NICE rationale, reduce
discount pressure, OR expand reimbursable population.
"""


# ---------------------------------------------------------------------- #
# Skill 6 — Predict with additional evidence (Logic 5)                   #
# ---------------------------------------------------------------------- #

PREDICT_WITH_ADDITIONAL_EVIDENCE_PROMPT = """\
You are performing LOGIC 5 — predict reimbursement and price corridor AFTER
applying the recommended evidence package from Logic 4.

# Core principle
This is a DELTA assessment, NOT a de novo forecast. Identify which decision
weaknesses are resolved, which remain, and how that changes likely access route
and acceptable price potential.

# Reassessment domains (re-evaluate each after the evidence improvement)
Comparator credibility; clinical benefit confidence; long-term evidence;
QoL and utility support; economic-model credibility; commercial flexibility
need; access breadth.

# Pathway transition rules
- not_recommended -> managed_access / restricted: when new evidence resolves
  the most acute comparator or maturity weakness but uncertainty is still material.
- managed_access -> restricted: when long-term evidence and modelling
  credibility improve enough for a more stable recommendation.
- restricted -> routine: when maturity, subgroup confidence, QoL support and
  economic plausibility ALL improve materially.
- no major change: when recommended evidence does not resolve the true
  decision-limiting issue, or pricing pressure remains too high.

# Corridor logic with improved evidence
- Better comparative evidence -> higher confidence in net value, raises corridor.
- Longer follow-up / durability -> reduces uncertainty discount, narrows range.
- Better QoL evidence -> strengthens upper end.
- Subgroup targeting -> improves both access probability and corridor.
- Managed-access plan -> may not maximise immediate corridor but supports
  reassessment & progression path.

# Build rule
Stay conservative. Do NOT assume Phase III evidence guarantees routine
recommendation. Test whether comparator, subgroup, QoL, durability,
commercial factors align with positive analogue precedents.

# Inputs
Base prediction (Logic 3): {base_prediction_json}
Evidence recommendations (Logic 4): {evidence_json}
Comparison (Logic 2): {comparison_json}
Commercial assumptions: {commercial_json}

# Output
Return ONLY a JSON object matching this schema:
{schema}

Required:
- `most_likely_progression_path` like
  'current evidence -> managed access -> reassessment -> restricted recommendation'.
- `updated_corridors` should include at minimum Base, Target and Upside.
"""


def render(template: str, **fields: Any) -> str:
    """Format a prompt template, JSON-encoding any non-string field values."""
    safe = {}
    for k, v in fields.items():
        if isinstance(v, str):
            safe[k] = v
        else:
            safe[k] = json.dumps(v, indent=2, default=str)
    return template.format(**safe)
