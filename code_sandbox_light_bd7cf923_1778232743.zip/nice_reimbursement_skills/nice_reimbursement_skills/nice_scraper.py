"""
NICE website scraper used by Skill 1 (NICEHistoryRetrievalSkill).

Implements the 8 logic steps described in `nice_history_page_logic.txt`:

    Step 1 — resolve correct NICE guidance record (search by generic / brand / indication)
    Step 2 — extract guidance code from URL / metadata
    Step 3 — confirm product identity from overview page
    Step 4 — derive history page URL (/guidance/{code}/history)
    Step 5 — parse all document entries from history page
    Step 6 — filter to product-related downloadable PDFs
    Step 7 — download PDFs (with retry, naming convention)
    Step 8 — return structured document index

Plus the four fallback rules from the source doc.

This module is intentionally self-contained — it has no LLM dependency.
"""
from __future__ import annotations

import logging
import os
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup
from slugify import slugify
from tenacity import retry, stop_after_attempt, wait_exponential

from .models import (
    AnalogueRef,
    DownloadedDocument,
    GuidanceRecord,
)

logger = logging.getLogger(__name__)

NICE_BASE = "https://www.nice.org.uk"
NICE_SEARCH = "https://www.nice.org.uk/search"

USER_AGENT = (
    "Mozilla/5.0 (compatible; nice-reimbursement-skills/0.1; "
    "+https://github.com/yourorg/nice_reimbursement_skills)"
)

GUIDANCE_CODE_RE = re.compile(r"/guidance/([a-z]+\d+)\b", re.IGNORECASE)
GUIDANCE_TYPES = ("ta", "hst", "ng", "dg", "mtg", "ipg", "cg")


# ---------------------------------------------------------------------- #
# Session                                                                #
# ---------------------------------------------------------------------- #

def _session() -> requests.Session:
    s = requests.Session()
    s.headers.update({"User-Agent": USER_AGENT, "Accept": "text/html,application/xhtml+xml"})
    return s


# ---------------------------------------------------------------------- #
# Step 1 — search for guidance record                                    #
# ---------------------------------------------------------------------- #

@retry(stop=stop_after_attempt(3), wait=wait_exponential(min=1, max=8))
def _search_nice(query: str, session: requests.Session) -> List[Dict[str, str]]:
    """Search NICE and return candidate guidance pages (title, url, snippet)."""
    resp = session.get(NICE_SEARCH, params={"q": query, "ndt": "Guidance"}, timeout=30)
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "lxml")
    results: List[Dict[str, str]] = []
    for a in soup.select("a[href*='/guidance/']"):
        href = a.get("href", "")
        m = GUIDANCE_CODE_RE.search(href)
        if not m:
            continue
        title = a.get_text(strip=True)
        if not title:
            continue
        url = urljoin(NICE_BASE, href.split("?")[0])
        # Cut to /guidance/{code}
        url = re.sub(r"(/guidance/[a-z]+\d+).*", r"\1", url, flags=re.IGNORECASE)
        results.append({
            "title": title,
            "url": url,
            "guidance_code": m.group(1).upper(),
        })
    # De-duplicate by guidance code, preserving order
    seen = set()
    unique: List[Dict[str, str]] = []
    for r in results:
        if r["guidance_code"] in seen:
            continue
        seen.add(r["guidance_code"])
        unique.append(r)
    return unique


def resolve_guidance_record(
    analogue: AnalogueRef,
    session: Optional[requests.Session] = None,
) -> GuidanceRecord:
    """
    Step 1 + 2 + 3 + 4 combined — resolve the most likely guidance record.

    Priority (per source doc):
        exact generic > exact brand > indication > target population/LoT/manufacturer
    """
    session = session or _session()
    record = GuidanceRecord(analogue_name=analogue.name)

    queries: List[Tuple[str, str]] = []
    if analogue.name:
        queries.append(("generic", analogue.name))
    if analogue.brand_name:
        queries.append(("brand", analogue.brand_name))
    if analogue.name and analogue.indication:
        queries.append(("generic+ind", f"{analogue.name} {analogue.indication}"))
    if analogue.brand_name and analogue.indication:
        queries.append(("brand+ind", f"{analogue.brand_name} {analogue.indication}"))

    candidates: List[Dict[str, str]] = []
    for _label, q in queries:
        try:
            candidates.extend(_search_nice(q, session))
        except Exception as e:
            logger.warning("NICE search failed for %r: %s", q, e)

    if not candidates:
        record.notes = "No NICE guidance candidates found."
        record.match_confidence = "none"
        return record

    # Disambiguate using fallback 2 rules: prefer matches that mention the generic
    # name in the title; then brand; then indication.
    def _score(cand: Dict[str, str]) -> int:
        title = cand["title"].lower()
        s = 0
        if analogue.name and analogue.name.lower() in title:
            s += 10
        if analogue.brand_name and analogue.brand_name.lower() in title:
            s += 7
        if analogue.indication and analogue.indication.lower() in title:
            s += 4
        if analogue.target_population and analogue.target_population.lower() in title:
            s += 2
        # Prefer TA / HST guidance over broader NG / DG
        code_prefix = "".join(c for c in cand["guidance_code"] if c.isalpha()).lower()
        if code_prefix in ("ta", "hst"):
            s += 3
        return s

    best = max(candidates, key=_score)
    score = _score(best)
    confidence = "high" if score >= 13 else "medium" if score >= 7 else "low"

    overview_url = best["url"]
    history_url = overview_url + "/history"

    record.nice_guidance_code = best["guidance_code"].upper()
    record.nice_guidance_title = best["title"]
    record.overview_url = overview_url
    record.history_url = history_url
    record.match_confidence = confidence

    # Step 3 — confirm identity from overview page
    try:
        overview = session.get(overview_url, timeout=30)
        if overview.ok:
            soup = BeautifulSoup(overview.text, "lxml")
            # Title (h1) usually contains generic [brand]
            h1 = soup.find("h1")
            if h1:
                title_text = h1.get_text(" ", strip=True)
                # extract generic + brand "Generic (Brand)"
                m = re.match(r"(.+?)\s*\((.+?)\)", title_text)
                if m:
                    record.generic_name = m.group(1).strip()
                    record.brand_name = m.group(2).strip()
                else:
                    record.generic_name = title_text
            # Guidance type from breadcrumbs / page metadata (ta, hst, ng...)
            code_letters = re.match(r"([A-Za-z]+)", record.nice_guidance_code or "")
            if code_letters:
                record.nice_guidance_type = code_letters.group(1).upper()
            # Indication: look for known patterns
            indication_meta = soup.find("meta", attrs={"name": "DC.subject"})
            if indication_meta and indication_meta.get("content"):
                record.indication = indication_meta["content"]
    except Exception as e:
        logger.warning("Overview page fetch failed for %s: %s", overview_url, e)

    return record


# ---------------------------------------------------------------------- #
# Step 5 + 6 — parse history page and filter PDFs                        #
# ---------------------------------------------------------------------- #

# Inclusion keywords from source doc
INCLUDE_SECTIONS = (
    "expected publication",
    "final appraisal determination",
    "draft guidance",
    "invitation to participate",
    "draft scope",
    "final scope",
    "matrix",
    "evaluation consultation",
    "appraisal consultation",
    "committee papers",
    "committee slides",
    "equality impact",
    "scoping",
    "stakeholder",
    "history",
)

INCLUDE_TITLE_TOKENS = (
    "committee paper",
    "committee slides",
    "appraisal consultation",
    "evaluation consultation",
    "final appraisal determination",
    "fad",
    "final scope",
    "matrix",
    "scope",
    "equality impact",
    "ergreport",
    "erg report",
    "company submission",
    "final guidance",
)


def _looks_like_product_pdf(href: str, label: str) -> bool:
    """Decide whether a link from the history page should be auto-downloaded."""
    if not href:
        return False
    href_l = href.lower()
    label_l = (label or "").lower()
    if href_l.endswith(".pdf"):
        return True
    # NICE often links to /resources/... that 302 to a PDF
    if "/resources/" in href_l and ("pdf" in label_l or "documents" in label_l):
        return True
    if any(tok in label_l for tok in INCLUDE_TITLE_TOKENS) and (
        "pdf" in label_l or "/resources/" in href_l
    ):
        return True
    return False


@retry(stop=stop_after_attempt(3), wait=wait_exponential(min=1, max=8))
def parse_history_page(
    history_url: str,
    session: Optional[requests.Session] = None,
) -> List[Dict[str, Optional[str]]]:
    """Step 5 — return all document entries from the NICE history page."""
    session = session or _session()
    resp = session.get(history_url, timeout=30)
    if not resp.ok:
        # Fallback 1: maybe the /history suffix didn't resolve. Try overview page tabs.
        overview_url = history_url.replace("/history", "")
        ov = session.get(overview_url, timeout=30)
        if not ov.ok:
            return []
        soup = BeautifulSoup(ov.text, "lxml")
        link = soup.find("a", href=re.compile(r"/history$"))
        if not link:
            return []
        history_url = urljoin(NICE_BASE, link["href"])
        resp = session.get(history_url, timeout=30)
        if not resp.ok:
            return []
    soup = BeautifulSoup(resp.text, "lxml")

    docs: List[Dict[str, Optional[str]]] = []
    # NICE history pages group docs in <section> blocks with <h2> section names.
    sections = soup.find_all(["section", "div"], class_=re.compile(r"history|panel|accordion", re.I))
    if not sections:
        sections = [soup]

    for section in sections:
        section_name = ""
        h = section.find(["h2", "h3"])
        if h:
            section_name = h.get_text(" ", strip=True)
        for a in section.find_all("a", href=True):
            href = a["href"]
            label = a.get_text(" ", strip=True)
            if not label:
                continue
            full_url = urljoin(NICE_BASE, href)

            # Try to extract a date sibling
            date_text = None
            sib = a.find_next(string=re.compile(r"\d{1,2}\s+\w+\s+\d{4}"))
            if sib:
                date_text = str(sib).strip()

            entry = {
                "section_name": section_name or None,
                "document_title": label,
                "publication_date": date_text,
                "source_url": full_url,
                "document_format": "PDF" if full_url.lower().endswith(".pdf") else None,
                "is_downloadable": _looks_like_product_pdf(href, label),
            }
            # De-duplicate
            if not any(d["source_url"] == full_url for d in docs):
                docs.append(entry)
    return docs


# ---------------------------------------------------------------------- #
# Step 7 — download PDFs                                                 #
# ---------------------------------------------------------------------- #

def _safe_filename(guidance_code: str, section: Optional[str], title: str, date: Optional[str]) -> str:
    """{guidance_code}__{section}__{document_title}__{date}.pdf"""
    parts = [
        slugify(guidance_code or "nice")[:20],
        slugify(section or "")[:30],
        slugify(title or "doc")[:80],
        slugify(date or "")[:20],
    ]
    name = "__".join(p for p in parts if p)
    return name[:200] + ".pdf"


@retry(stop=stop_after_attempt(3), wait=wait_exponential(min=1, max=10))
def _download(url: str, dest: Path, session: requests.Session) -> Tuple[int, str]:
    with session.get(url, stream=True, timeout=60, allow_redirects=True) as r:
        r.raise_for_status()
        ctype = r.headers.get("Content-Type", "")
        dest.parent.mkdir(parents=True, exist_ok=True)
        size = 0
        with open(dest, "wb") as f:
            for chunk in r.iter_content(chunk_size=64 * 1024):
                if chunk:
                    f.write(chunk)
                    size += len(chunk)
        return size, ctype


def download_documents(
    guidance: GuidanceRecord,
    entries: List[Dict[str, Optional[str]]],
    download_dir: str,
    download_pdfs: bool = True,
    max_documents: Optional[int] = None,
    session: Optional[requests.Session] = None,
) -> List[DownloadedDocument]:
    """Steps 6 + 7 — filter and download PDFs."""
    session = session or _session()
    base = Path(download_dir) / slugify(guidance.analogue_name) / (guidance.nice_guidance_code or "unknown") / "history_documents"

    out: List[DownloadedDocument] = []
    count = 0
    for e in entries:
        if max_documents is not None and count >= max_documents:
            break

        is_pdf = e.get("is_downloadable") or (e.get("document_format") == "PDF")
        doc = DownloadedDocument(
            analogue_name=guidance.analogue_name,
            guidance_code=guidance.nice_guidance_code,
            section_name=e.get("section_name"),
            document_title=e.get("document_title") or "untitled",
            publication_date=e.get("publication_date"),
            document_format=e.get("document_format"),
            source_url=e["source_url"],
        )

        if not is_pdf:
            doc.download_status = "non_pdf"
            out.append(doc)
            continue

        if not download_pdfs:
            doc.download_status = "skipped"
            out.append(doc)
            continue

        fname = _safe_filename(
            guidance.nice_guidance_code or "",
            doc.section_name,
            doc.document_title,
            doc.publication_date,
        )
        dest = base / fname
        try:
            size, ctype = _download(doc.source_url, dest, session)
            doc.local_path = str(dest)
            doc.file_size_bytes = size
            if "pdf" in ctype.lower() or dest.suffix.lower() == ".pdf":
                doc.download_status = "downloaded"
                doc.document_format = "PDF"
                count += 1
            else:
                doc.download_status = "non_pdf"
                # Keep file for inspection but flag it
        except Exception as ex:
            doc.download_status = "failed"
            doc.error = str(ex)
        out.append(doc)
    return out


# ---------------------------------------------------------------------- #
# Public entrypoint used by the skill                                    #
# ---------------------------------------------------------------------- #

def retrieve_for_analogue(
    analogue: AnalogueRef,
    download_dir: str,
    download_pdfs: bool = True,
    max_documents: Optional[int] = None,
) -> Tuple[GuidanceRecord, List[DownloadedDocument]]:
    """End-to-end: search -> resolve -> parse history -> download PDFs."""
    session = _session()
    guidance = resolve_guidance_record(analogue, session=session)
    if not guidance.history_url:
        return guidance, []
    entries = parse_history_page(guidance.history_url, session=session)
    if not entries:
        # Fallback 4 — history page exists but no PDFs / entries
        return guidance, []
    docs = download_documents(
        guidance,
        entries,
        download_dir=download_dir,
        download_pdfs=download_pdfs,
        max_documents=max_documents,
        session=session,
    )
    return guidance, docs
