"""
PDF text-extraction utilities used by Skill 2 (AnalyzeOneAnalogueSkill).

We try `pypdf` first (fast, pure-python). If a PDF returns very little text
(common for scanned committee slides), we fall back to `pdfminer.six` which
extracts more reliably from layout-heavy documents.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Iterable, List, Tuple

logger = logging.getLogger(__name__)


def extract_text(path: str | Path) -> str:
    """Return the full text of a PDF as a single string."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(p)

    text = _try_pypdf(p)
    if len(text.strip()) < 200:
        try:
            text2 = _try_pdfminer(p)
            if len(text2.strip()) > len(text.strip()):
                text = text2
        except Exception as e:
            logger.warning("pdfminer fallback failed for %s: %s", p, e)
    return text


def _try_pypdf(p: Path) -> str:
    try:
        from pypdf import PdfReader
    except ImportError:
        return ""
    try:
        reader = PdfReader(str(p))
        pages: List[str] = []
        for page in reader.pages:
            try:
                pages.append(page.extract_text() or "")
            except Exception:
                pages.append("")
        return "\n\n".join(pages)
    except Exception as e:
        logger.warning("pypdf failed for %s: %s", p, e)
        return ""


def _try_pdfminer(p: Path) -> str:
    from pdfminer.high_level import extract_text as miner_extract
    return miner_extract(str(p))


def chunk_text(text: str, chunk_chars: int = 60000, overlap: int = 1000) -> List[str]:
    """Split a long text into overlapping chunks safe for an LLM context window."""
    if len(text) <= chunk_chars:
        return [text]
    chunks: List[str] = []
    start = 0
    while start < len(text):
        end = min(len(text), start + chunk_chars)
        chunks.append(text[start:end])
        if end == len(text):
            break
        start = end - overlap
    return chunks


def label_for_doc(title: str | None, section: str | None) -> str:
    """Produce a short label like '[FAD] Final appraisal determination'."""
    title = (title or "").strip()
    section = (section or "").strip()
    if section and title:
        return f"[{section}] {title}"
    return title or section or "document"


def collate_documents(docs: Iterable[Tuple[str, str]]) -> str:
    """
    Concatenate (label, text) pairs into one prompt-ready blob, preserving
    source attribution so the LLM can populate `source_traceability`.
    """
    parts: List[str] = []
    for label, text in docs:
        parts.append(f"\n\n========== SOURCE: {label} ==========\n{text}")
    return "".join(parts)
