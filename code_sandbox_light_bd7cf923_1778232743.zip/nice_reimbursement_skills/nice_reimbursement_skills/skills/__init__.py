"""All skill classes."""
from .s0_analogue_identification import AnalogueIdentificationSkill
from .s1_nice_history_retrieval import NICEHistoryRetrievalSkill
from .s2_analyze_one_analogue import AnalyzeOneAnalogueSkill
from .s3_compare_all_analogues import CompareAllAnaloguesSkill
from .s4_predict_current_evidence import PredictCurrentEvidenceSkill
from .s5_recommend_additional_evidence import RecommendAdditionalEvidenceSkill
from .s6_predict_with_additional_evidence import PredictWithAdditionalEvidenceSkill

__all__ = [
    "AnalogueIdentificationSkill",
    "NICEHistoryRetrievalSkill",
    "AnalyzeOneAnalogueSkill",
    "CompareAllAnaloguesSkill",
    "PredictCurrentEvidenceSkill",
    "RecommendAdditionalEvidenceSkill",
    "PredictWithAdditionalEvidenceSkill",
]
