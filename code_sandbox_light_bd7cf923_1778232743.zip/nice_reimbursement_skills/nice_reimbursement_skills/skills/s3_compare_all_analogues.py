"""
Skill 3 — Compare results across all analogues / competitors.

Source: logic_2_compare_all_analogues.txt
"""
from __future__ import annotations

from typing import Any, Optional

from ..base import BaseSkill, registry
from ..llm_client import LLMClient
from ..models import (
    CompareAllAnaloguesInput,
    CompareAllAnaloguesOutput,
)
from ..prompts import COMPARE_ALL_ANALOGUES_PROMPT, render


class CompareAllAnaloguesSkill(BaseSkill[CompareAllAnaloguesInput, CompareAllAnaloguesOutput]):
    name = "compare_all_analogues"
    description = (
        "Logic 2: convert multiple single-analogue NICE profiles into a "
        "comparative evidence set. Splits competitors vs broader analogues, "
        "tags each as supportive / cautionary / boundary-case precedent, "
        "ranks by predictive relevance, and synthesises NICE decision patterns "
        "(access route, restriction reasons, evidence maturity, PAS use, "
        "timing, appeal frequency)."
    )
    input_model = CompareAllAnaloguesInput
    output_model = CompareAllAnaloguesOutput

    def __init__(self, llm_client: Optional[LLMClient] = None, **kwargs: Any):
        super().__init__(llm_client=llm_client, **kwargs)

    def run(self, input_obj: CompareAllAnaloguesInput) -> CompareAllAnaloguesOutput:
        if self.llm_client is None:
            raise RuntimeError("CompareAllAnaloguesSkill needs an LLMClient.")

        prompt = render(
            COMPARE_ALL_ANALOGUES_PROMPT,
            product_a_json=input_obj.product_a.model_dump(),
            profiles_json=[p.model_dump() for p in input_obj.profiles],
            schema=self.output_json_schema(),
        )
        raw = self.llm_client.json_complete(prompt)
        return CompareAllAnaloguesOutput.model_validate(raw)


registry.register(CompareAllAnaloguesSkill())
