"""
Skill 5 — Recommend additional evidence to improve reimbursement / price.

Source: logic_4_recommend_additional_evidence.txt
"""
from __future__ import annotations

from typing import Any, Optional

from ..base import BaseSkill, registry
from ..llm_client import LLMClient
from ..models import (
    RecommendAdditionalEvidenceInput,
    RecommendAdditionalEvidenceOutput,
)
from ..prompts import RECOMMEND_ADDITIONAL_EVIDENCE_PROMPT, render


class RecommendAdditionalEvidenceSkill(BaseSkill[RecommendAdditionalEvidenceInput, RecommendAdditionalEvidenceOutput]):
    name = "recommend_additional_evidence"
    description = (
        "Logic 4: identify the minimum but decision-relevant additional "
        "evidence package that would improve reimbursement probability and "
        "widen Product A's acceptable price corridor. Each recommendation is "
        "tied to a specific NICE weakness from Logic 3 and an analogue "
        "precedent showing the issue mattered."
    )
    input_model = RecommendAdditionalEvidenceInput
    output_model = RecommendAdditionalEvidenceOutput

    def __init__(self, llm_client: Optional[LLMClient] = None, **kwargs: Any):
        super().__init__(llm_client=llm_client, **kwargs)

    def run(self, input_obj: RecommendAdditionalEvidenceInput) -> RecommendAdditionalEvidenceOutput:
        if self.llm_client is None:
            raise RuntimeError("RecommendAdditionalEvidenceSkill needs an LLMClient.")

        prompt = render(
            RECOMMEND_ADDITIONAL_EVIDENCE_PROMPT,
            product_a_json=input_obj.product_a.model_dump(),
            base_prediction_json=input_obj.base_prediction.model_dump(),
            comparison_json=input_obj.comparison.model_dump(),
            schema=self.output_json_schema(),
        )
        raw = self.llm_client.json_complete(prompt)
        return RecommendAdditionalEvidenceOutput.model_validate(raw)


registry.register(RecommendAdditionalEvidenceSkill())
