"""
Skill 6 — Predict reimbursement & price corridor WITH additional evidence.

Source: logic_5_predict_with_additional_evidence.txt
"""
from __future__ import annotations

from typing import Any, Optional

from ..base import BaseSkill, registry
from ..llm_client import LLMClient
from ..models import (
    PredictWithAdditionalEvidenceInput,
    PredictWithAdditionalEvidenceOutput,
)
from ..prompts import PREDICT_WITH_ADDITIONAL_EVIDENCE_PROMPT, render


class PredictWithAdditionalEvidenceSkill(BaseSkill[PredictWithAdditionalEvidenceInput, PredictWithAdditionalEvidenceOutput]):
    name = "predict_with_additional_evidence"
    description = (
        "Logic 5: rerun the NICE-style assessment AFTER applying the evidence "
        "package recommended by Logic 4. Delta assessment: identifies which "
        "decision weaknesses are resolved, which remain, and how that changes "
        "likely access route and acceptable price potential. Produces updated "
        "Base / Target / Upside corridors and a most-likely progression path."
    )
    input_model = PredictWithAdditionalEvidenceInput
    output_model = PredictWithAdditionalEvidenceOutput

    def __init__(self, llm_client: Optional[LLMClient] = None, **kwargs: Any):
        super().__init__(llm_client=llm_client, **kwargs)

    def run(self, input_obj: PredictWithAdditionalEvidenceInput) -> PredictWithAdditionalEvidenceOutput:
        if self.llm_client is None:
            raise RuntimeError("PredictWithAdditionalEvidenceSkill needs an LLMClient.")

        prompt = render(
            PREDICT_WITH_ADDITIONAL_EVIDENCE_PROMPT,
            base_prediction_json=input_obj.base_prediction.model_dump(),
            evidence_json=input_obj.evidence_recommendations.model_dump(),
            comparison_json=input_obj.comparison.model_dump(),
            commercial_json=input_obj.commercial_assumptions.model_dump(),
            schema=self.output_json_schema(),
        )
        raw = self.llm_client.json_complete(prompt)
        return PredictWithAdditionalEvidenceOutput.model_validate(raw)


registry.register(PredictWithAdditionalEvidenceSkill())
