"""
Skill 2 — Analyse all NICE files for ONE analogue / competitor.

Source: logic_1_analyze_one_analogue.txt

Reads every downloaded PDF for one analogue, extracts text, and asks the LLM
to populate the structured AnalogueProfile (the 11-block extraction object
described in the source doc).

For very long documents (e.g. 200-page committee papers) the text is chunked,
each chunk is summarised into a partial profile, and the partials are merged
in a final pass. This keeps the skill robust regardless of LLM context size.
"""
from __future__ import annotations

import json
import logging
from typing import Any, List, Optional

from ..base import BaseSkill, registry
from ..llm_client import LLMClient
from ..models import (
    AnalogueProfile,
    AnalyzeOneAnalogueInput,
    AnalyzeOneAnalogueOutput,
    SourceTraceability,
)
from ..pdf_utils import chunk_text, extract_text, label_for_doc
from ..prompts import ANALYZE_ONE_ANALOGUE_PROMPT, render

logger = logging.getLogger(__name__)

MERGE_PROMPT = """\
You previously extracted partial NICE analogue profiles from different chunks
of source documents for the same product. Merge them into ONE consistent
AnalogueProfile JSON object. Rules:

- Prefer values from FAD / Final guidance over committee papers when they conflict.
- Keep all distinct committee_concerns; deduplicate by concern text.
- Combine source_traceability lists (deduplicated by source_document_title).
- Preserve public_vs_non_public_flags; if any source flagged a field as
  non_public, keep that flag.

Partial profiles:
{partials_json}

Return ONLY a JSON object matching this schema:
{schema}
"""


class AnalyzeOneAnalogueSkill(BaseSkill[AnalyzeOneAnalogueInput, AnalyzeOneAnalogueOutput]):
    name = "analyze_one_analogue"
    description = (
        "Logic 1: ingest every NICE PDF for one analogue/competitor and "
        "produce a structured AnalogueProfile (identity, process metadata, "
        "final access outcome, reimbursed population, comparator logic, "
        "clinical & economic logic, committee concerns, commercial logic, "
        "timing logic, full source traceability)."
    )
    input_model = AnalyzeOneAnalogueInput
    output_model = AnalyzeOneAnalogueOutput

    def __init__(self, llm_client: Optional[LLMClient] = None, **kwargs: Any):
        super().__init__(llm_client=llm_client, **kwargs)

    # ---- helpers ------------------------------------------------------ #

    @staticmethod
    def _docs_to_blob(docs, chunk_chars: int) -> List[str]:
        """Build per-chunk prompt blobs that include source attribution."""
        labelled: List[tuple[str, str]] = []
        for d in docs:
            if not d.local_path:
                continue
            try:
                text = extract_text(d.local_path)
            except Exception as e:
                logger.warning("Could not extract %s: %s", d.local_path, e)
                continue
            label = label_for_doc(d.document_title, d.section_name)
            labelled.append((label, text))

        # Concatenate then chunk so chunk boundaries are agnostic to file order.
        big = ""
        for label, text in labelled:
            big += f"\n\n========== SOURCE: {label} ==========\n{text}"
        return chunk_text(big, chunk_chars=chunk_chars)

    # ---- main --------------------------------------------------------- #

    def run(self, input_obj: AnalyzeOneAnalogueInput) -> AnalyzeOneAnalogueOutput:
        if self.llm_client is None:
            raise RuntimeError("AnalyzeOneAnalogueSkill needs an LLMClient.")

        downloaded = [d for d in input_obj.documents if d.download_status == "downloaded"]
        if not downloaded:
            # Return a stub profile so the pipeline can still continue.
            stub = AnalogueProfile.model_construct(
                analogue_identity={"product_name": input_obj.analogue_name},
                process_metadata={"ta_or_hst_id": input_obj.guidance_code},
                final_access_outcome={"outcome": "unknown"},
                reimbursed_population={},
                comparator_logic={},
                clinical_logic={},
                economic_logic={},
                commercial_logic={},
                timing_logic={},
                committee_concerns=[],
                source_traceability=[],
            )
            return AnalyzeOneAnalogueOutput(
                profile=AnalogueProfile.model_validate(stub.model_dump())
            )

        chunks = self._docs_to_blob(downloaded, input_obj.chunk_chars)
        schema = self.output_json_schema()

        partials: List[dict] = []
        for i, blob in enumerate(chunks, 1):
            logger.info("Analyzing chunk %s/%s for %s", i, len(chunks), input_obj.analogue_name)
            prompt = render(
                ANALYZE_ONE_ANALOGUE_PROMPT,
                analogue_name=input_obj.analogue_name,
                guidance_code=input_obj.guidance_code or "(unknown)",
                documents_blob=blob,
                schema=schema,
            )
            partial = self.llm_client.json_complete(prompt)
            partials.append(partial)

        if len(partials) == 1:
            merged = partials[0]
        else:
            merge_prompt = MERGE_PROMPT.format(
                partials_json=json.dumps(partials, indent=2, default=str),
                schema=json.dumps(schema, indent=2),
            )
            merged = self.llm_client.json_complete(merge_prompt)

        # The model sometimes returns the wrapping {"profile": {...}} or the bare profile.
        if "profile" in merged and isinstance(merged["profile"], dict):
            return AnalyzeOneAnalogueOutput.model_validate(merged)
        return AnalyzeOneAnalogueOutput(profile=AnalogueProfile.model_validate(merged))


registry.register(AnalyzeOneAnalogueSkill())
