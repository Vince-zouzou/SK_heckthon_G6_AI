"""
Skill 1 — NICE history-page retrieval and PDF download.

Source: nice_history_page_logic.txt

This skill is product-agnostic and DOES NOT call an LLM — all logic is
deterministic web scraping (NICE search -> overview -> history -> PDFs).
"""
from __future__ import annotations

import logging
import os
from typing import Any, Optional

from tqdm import tqdm

from ..base import BaseSkill, registry
from ..llm_client import LLMClient
from ..models import (
    AnalogueRef,
    NICEHistoryRetrievalInput,
    NICEHistoryRetrievalOutput,
)
from ..nice_scraper import retrieve_for_analogue

logger = logging.getLogger(__name__)


class NICEHistoryRetrievalSkill(BaseSkill[NICEHistoryRetrievalInput, NICEHistoryRetrievalOutput]):
    name = "nice_history_retrieval"
    description = (
        "For each user-confirmed analogue/competitor: resolve the correct "
        "NICE guidance record, derive the history page URL, parse all "
        "document entries, and download the relevant PDFs (committee papers, "
        "FAD, ACD, ERG critique, scoping, EIA). Returns guidance records and "
        "a structured document index."
    )
    input_model = NICEHistoryRetrievalInput
    output_model = NICEHistoryRetrievalOutput

    def __init__(self, llm_client: Optional[LLMClient] = None, **kwargs: Any):
        super().__init__(llm_client=llm_client, **kwargs)

    def run(self, input_obj: NICEHistoryRetrievalInput) -> NICEHistoryRetrievalOutput:
        os.makedirs(input_obj.download_dir, exist_ok=True)

        guidance_records = []
        all_docs = []
        failures: list[str] = []
        history_pages_found = 0
        pdfs_downloaded = 0

        iterator = tqdm(input_obj.analogues, desc="NICE retrieval", unit="analogue")
        for analogue in iterator:
            try:
                guidance, docs = retrieve_for_analogue(
                    analogue,
                    download_dir=input_obj.download_dir,
                    download_pdfs=input_obj.download_pdfs,
                    max_documents=input_obj.max_documents_per_analogue,
                )
                guidance_records.append(guidance)
                all_docs.extend(docs)
                if guidance.history_url and docs:
                    history_pages_found += 1
                pdfs_downloaded += sum(1 for d in docs if d.download_status == "downloaded")
            except Exception as e:
                logger.exception("Retrieval failed for analogue %s", analogue.name)
                failures.append(f"{analogue.name}: {e}")

        return NICEHistoryRetrievalOutput(
            guidance_records=guidance_records,
            documents=all_docs,
            history_pages_found=history_pages_found,
            pdfs_downloaded=pdfs_downloaded,
            failures=failures,
        )


registry.register(NICEHistoryRetrievalSkill())
