"""
Skill 4 — Predict reimbursement & price corridor on existing evidence.

Source: logic_3_predict_current_evidence.txt
"""
from __future__ import annotations

from typing import Any, Optional

from ..base import BaseSkill, registry
from ..llm_client import LLMClient
from ..models import (
    PredictCurrentEvidenceInput,
    PredictCurrentEvidenceOutput,
)
from ..prompts import PREDICT_CURRENT_EVIDENCE_PROMPT, render


class PredictCurrentEvidenceSkill(BaseSkill[PredictCurrentEvidenceInput, PredictCurrentEvidenceOutput]):
    name = "predict_current_evidence"
    description = (
        "Logic 3: translate the analogue comparison and Product A's current "
        "evidence into a likely NICE reimbursement pathway and base-case "
        "price corridor (Conservative / Base / Optimistic). Produces a "
        "ranked list of NICE concerns that Logic 4 will consume."
    )
    input_model = PredictCurrentEvidenceInput
    output_model = PredictCurrentEvidenceOutput

    def __init__(self, llm_client: Optional[LLMClient] = None, **kwargs: Any):
        super().__init__(llm_client=llm_client, **kwargs)

    def run(self, input_obj: PredictCurrentEvidenceInput) -> PredictCurrentEvidenceOutput:
        if self.llm_client is None:
            raise RuntimeError("PredictCurrentEvidenceSkill needs an LLMClient.")

        prompt = render(
            PREDICT_CURRENT_EVIDENCE_PROMPT,
            product_a_json=input_obj.product_a.model_dump(),
            current_evidence_json=input_obj.current_evidence.model_dump(),
            comparison_json=input_obj.comparison.model_dump(),
            commercial_json=input_obj.commercial_assumptions.model_dump(),
            schema=self.output_json_schema(),
        )
        raw = self.llm_client.json_complete(prompt)
        return PredictCurrentEvidenceOutput.model_validate(raw)


registry.register(PredictCurrentEvidenceSkill())
