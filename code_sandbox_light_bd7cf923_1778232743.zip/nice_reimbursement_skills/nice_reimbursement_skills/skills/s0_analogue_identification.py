"""
Skill 0 — Analogue Identification.

Source: analogue_identification_recommendation_fixed.txt

The skill is competitor-first: a product is a competitor only if it matches
Product A on indication + line of therapy + target population. Other comparable
products are core or supporting analogues.

The output explicitly stops at the analogue list and demands user
confirmation before any NICE retrieval begins (matches the 'Mandatory user
confirmation gate' in the explainable landscape template).
"""
from __future__ import annotations

from typing import Any, Optional

from ..base import BaseSkill, registry
from ..llm_client import LLMClient
from ..models import (
    AnalogueIdentificationInput,
    AnalogueIdentificationOutput,
)
from ..prompts import ANALOGUE_IDENTIFICATION_PROMPT, render


class AnalogueIdentificationSkill(BaseSkill[AnalogueIdentificationInput, AnalogueIdentificationOutput]):
    name = "analogue_identification"
    description = (
        "Produce a defensible shortlist of competitors and analogues for "
        "Product A using competitor-first logic. Stops with a user-confirmation "
        "gate before any NICE retrieval. Pure product-matching — does NOT "
        "assess reimbursement strength, evidence quality, or NICE outcomes."
    )
    input_model = AnalogueIdentificationInput
    output_model = AnalogueIdentificationOutput

    def __init__(self, llm_client: Optional[LLMClient] = None, **kwargs: Any):
        super().__init__(llm_client=llm_client, **kwargs)

    def run(self, input_obj: AnalogueIdentificationInput) -> AnalogueIdentificationOutput:
        if self.llm_client is None:
            raise RuntimeError(
                "AnalogueIdentificationSkill needs an LLMClient. "
                "Pass one via the constructor."
            )

        prompt = render(
            ANALOGUE_IDENTIFICATION_PROMPT,
            product_a_json=input_obj.product_a.model_dump(),
            extra_context=input_obj.extra_context or "(none)",
            max_competitors=input_obj.max_competitors,
            max_analogues=input_obj.max_analogues,
            schema=self.output_json_schema(),
        )
        raw = self.llm_client.json_complete(prompt)
        # The output_model accepts extra fields gracefully; pydantic will validate.
        result = AnalogueIdentificationOutput.model_validate(raw)
        # Hard-enforce the user-confirmation gate from the source doc.
        result.requires_user_confirmation = True
        return result


# Register into the global registry
registry.register(AnalogueIdentificationSkill())
