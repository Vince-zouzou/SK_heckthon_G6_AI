"""
Pydantic models shared by all skills.

These models are the *contract* between skills. They are derived directly from
the input/output tables described in the source documents:

    * analogue_identification_recommendation_fixed.txt
    * nice_history_page_logic.txt
    * logic_1_analyze_one_analogue.txt
    * logic_2_compare_all_analogues.txt
    * logic_3_predict_current_evidence.txt
    * logic_4_recommend_additional_evidence.txt
    * logic_5_predict_with_additional_evidence.txt
    * reimbursement_potential_output_explainable_landscape.txt

Type aliases at the top encode the controlled vocabularies that the source docs
demand (e.g. NICE outcome taxonomy, relevance levels, evidence-gap categories).
"""
from __future__ import annotations

from datetime import date
from enum import Enum
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, HttpUrl


# =====================================================================
# Controlled vocabularies (from the source docs)
# =====================================================================

class ProductClassification(str, Enum):
    """analogue_identification: 'Competitor / Core analogue / Supporting analogue'."""
    competitor = "competitor"
    core_analogue = "core_analogue"
    supporting_analogue = "supporting_analogue"


class RelevanceLevel(str, Enum):
    high = "High"
    moderate = "Moderate"
    low = "Low"


class FitLevel(str, Enum):
    strong = "Strong"
    moderate = "Moderate"
    weak = "Weak"


class NICEOutcome(str, Enum):
    """Logic 2 normalised outcome taxonomy."""
    recommended = "recommended"
    recommended_with_restrictions = "recommended_with_restrictions"
    managed_access = "managed_access"   # CDF / managed access
    not_recommended = "not_recommended"
    terminated = "terminated"
    unknown = "unknown"


class PrecedentClass(str, Enum):
    """Logic 2 classification of analogues."""
    primary_competitor = "primary_competitor_precedent"
    primary_analogue = "primary_analogue_precedent"
    negative = "negative_or_constrained_precedent"
    timing_or_process = "timing_or_process_precedent"


class PredictedPathway(str, Enum):
    """Logic 3 / Logic 5 outcome prediction taxonomy."""
    routine_recommendation = "routine_recommendation"
    restricted_recommendation = "restricted_recommendation"
    managed_access = "managed_access"
    not_recommended = "not_recommended"


class EvidenceGapCategory(str, Enum):
    """Logic 4 evidence-gap taxonomy."""
    comparative_efficacy = "comparative_efficacy_gap"
    long_term_durability = "long_term_durability_gap"
    qol_utility = "qol_utility_gap"
    subgroup_definition = "subgroup_definition_gap"
    resource_use_bsc = "resource_use_bsc_gap"
    real_world_evidence = "real_world_evidence_gap"


class Priority(str, Enum):
    high = "High"
    medium = "Medium"
    low = "Low"


class IssueResolution(str, Enum):
    resolved = "resolved"
    partly_resolved = "partly_resolved"
    unresolved = "unresolved"


# =====================================================================
# Skill 0 — Analogue identification
# =====================================================================

class ProductA(BaseModel):
    """Description of the asset under assessment (Product A)."""
    model_config = ConfigDict(extra="allow")

    name: str = Field(..., description="Internal name (e.g. 'Product A').")
    indication: str
    line_of_therapy: Optional[str] = None
    target_population: Optional[str] = None
    biomarker_or_subgroup: Optional[str] = None
    mechanism_of_action: Optional[str] = None
    drug_class: Optional[str] = None
    route_of_administration: Optional[str] = None
    rarity_context: Optional[str] = Field(
        None, description="ultra-rare / orphan / non-orphan"
    )
    development_stage: Optional[str] = Field(
        None, description="e.g. 'Phase II results available; not yet launched'."
    )
    expected_launch: Optional[str] = None
    payer_geography: str = Field(
        "England and Wales / NICE",
        description="Free-text geography or payer scope.",
    )
    user_notes: Optional[str] = None


class AnalogueIdentificationInput(BaseModel):
    product_a: ProductA
    max_competitors: int = 6
    max_analogues: int = 8
    extra_context: Optional[str] = Field(
        None,
        description="Optional free-text additional context (e.g. internal therapy area knowledge).",
    )


class FitAssessment(BaseModel):
    """View 1A: criterion-by-criterion fit."""
    criterion: str
    product_a_value: Optional[str] = None
    analogue_value: Optional[str] = None
    fit_level: FitLevel
    why_it_matters: Optional[str] = None


class ProposedAnalogue(BaseModel):
    """One row of Output 1 in the explainable landscape template."""
    rank: int
    name: str = Field(..., description="Generic name; brand in parentheses if known.")
    brand_name: Optional[str] = None
    classification: ProductClassification
    overall_relevance: RelevanceLevel
    nice_appraisal_id: Optional[str] = Field(
        None, description="e.g. 'TA534', 'HST10'."
    )
    known_nice_outcome: Optional[NICEOutcome] = None
    indication_fit: Optional[FitLevel] = None
    line_of_therapy_fit: Optional[FitLevel] = None
    population_fit: Optional[FitLevel] = None
    biomarker_fit: Optional[FitLevel] = None
    moa_class_fit: Optional[FitLevel] = None
    treatment_paradigm_fit: Optional[FitLevel] = None
    administration_fit: Optional[FitLevel] = None
    rarity_fit: Optional[FitLevel] = None
    launch_recency_fit: Optional[FitLevel] = None
    geography_fit: Optional[FitLevel] = None
    procedural_note: Optional[str] = None
    why_relevant: str = Field(..., description="Top reasons for inclusion.")
    key_caveat: str
    suggested_action: Literal["Include", "Optional", "Include if user agrees"] = "Include"
    timing_note: Optional[str] = Field(
        None,
        description="UK launch / NICE decision date / time to decision / appeal flag.",
    )
    inclusion_status_default: Literal["included", "optional", "pending_user_confirmation"] = "included"


class ExcludedCandidate(BaseModel):
    """View 1B."""
    name: str
    reason_excluded: str
    could_be_boundary_case: bool = False


class AnalogueIdentificationOutput(BaseModel):
    """Output 1 + View 1A + View 1B + user-confirmation gate."""
    proposed_analogues: List[ProposedAnalogue]
    fit_matrix: List[FitAssessment] = Field(
        default_factory=list,
        description="Cross-cutting fit assessment per criterion (View 1A).",
    )
    excluded_candidates: List[ExcludedCandidate] = Field(default_factory=list)
    requires_user_confirmation: bool = True
    confirmation_options: List[str] = Field(
        default_factory=lambda: [
            "A. Proceed with the recommended analogue list",
            "B. Remove one or more proposed analogues",
            "C. Add additional analogue(s)",
            "D. Replace with a user-provided list",
            "E. Keep some as boundary-case analogues only",
        ]
    )
    notes: Optional[str] = None


# =====================================================================
# Skill 1 — NICE history retrieval
# =====================================================================

class AnalogueRef(BaseModel):
    """Minimum identifying info to look up an analogue on NICE."""
    name: str = Field(..., description="Generic name preferred.")
    brand_name: Optional[str] = None
    indication: Optional[str] = None
    line_of_therapy: Optional[str] = None
    target_population: Optional[str] = None
    manufacturer: Optional[str] = None
    nice_relevance_flag: bool = True


class NICEHistoryRetrievalInput(BaseModel):
    analogues: List[AnalogueRef]
    download_dir: str = Field(
        "./nice_documents",
        description="Local directory under which PDFs will be stored.",
    )
    download_pdfs: bool = True
    max_documents_per_analogue: Optional[int] = None


class GuidanceRecord(BaseModel):
    """Output A — NICE guidance resolution."""
    analogue_name: str
    generic_name: Optional[str] = None
    brand_name: Optional[str] = None
    nice_guidance_title: Optional[str] = None
    nice_guidance_type: Optional[str] = Field(
        None, description="TA / HST / NG / DG / etc."
    )
    nice_guidance_code: Optional[str] = Field(None, description="e.g. 'TA534'")
    overview_url: Optional[str] = None
    history_url: Optional[str] = None
    indication: Optional[str] = None
    match_confidence: Literal["high", "medium", "low", "none"] = "none"
    notes: Optional[str] = None


class DownloadedDocument(BaseModel):
    """Output C — one downloaded NICE document entry."""
    analogue_name: str
    guidance_code: Optional[str] = None
    section_name: Optional[str] = None
    document_title: str
    publication_date: Optional[str] = None
    document_format: Optional[str] = None
    source_url: str
    local_path: Optional[str] = None
    download_status: Literal["downloaded", "failed", "skipped", "non_pdf"] = "skipped"
    file_size_bytes: Optional[int] = None
    error: Optional[str] = None


class NICEHistoryRetrievalOutput(BaseModel):
    guidance_records: List[GuidanceRecord]
    documents: List[DownloadedDocument]
    history_pages_found: int = 0
    pdfs_downloaded: int = 0
    failures: List[str] = Field(default_factory=list)


# =====================================================================
# Skill 2 — Analyze ONE analogue (Logic 1)
# =====================================================================

class AnalogueIdentity(BaseModel):
    product_name: Optional[str] = None
    company: Optional[str] = None
    indication: Optional[str] = None
    biomarker_or_subgroup: Optional[str] = None
    line_of_therapy: Optional[str] = None
    mechanism_or_class: Optional[str] = None
    route_of_administration: Optional[str] = None


class ProcessMetadata(BaseModel):
    ta_or_hst_id: Optional[str] = None
    appraisal_committee_date: Optional[str] = None
    publication_date: Optional[str] = None
    appeal_occurred: Optional[bool] = None
    recommendation_changed_after_appeal: Optional[bool] = None
    used_cdf_or_managed_access: Optional[bool] = None


class FinalAccessOutcome(BaseModel):
    outcome: NICEOutcome = NICEOutcome.unknown
    optimised_recommendation_wording: Optional[str] = None


class ReimbursedPopulation(BaseModel):
    exact_population_wording: Optional[str] = None
    prior_treatment_requirement: Optional[str] = None
    subgroup_limitations: Optional[str] = None
    stopping_criteria: Optional[str] = None
    clinician_prescribing_restrictions: Optional[str] = None


class ComparatorLogic(BaseModel):
    comparator_accepted_by_nice: Optional[str] = None
    comparator_challenged_by_nice: Optional[str] = None
    bsc_definition: Optional[str] = None
    indirect_comparison_used: Optional[bool] = None
    active_comparator_gap: Optional[bool] = None


class ClinicalEvidenceLogic(BaseModel):
    pivotal_study_names: List[str] = Field(default_factory=list)
    phase: Optional[str] = None
    design: Optional[str] = None
    endpoints: List[str] = Field(default_factory=list)
    response_timing: Optional[str] = None
    long_term_evidence: Optional[str] = None
    safety_pattern: Optional[str] = None
    qol_data_availability: Optional[str] = None


class EconomicEvidenceLogic(BaseModel):
    base_case_icer_range: Optional[str] = None
    main_sensitivity_drivers: List[str] = Field(default_factory=list)
    waning_assumptions: Optional[str] = None
    discontinuation_assumptions: Optional[str] = None
    responder_handling: Optional[str] = None
    utility_assumptions: Optional[str] = None
    resource_use_assumptions: Optional[str] = None


class CommitteeConcern(BaseModel):
    concern: str
    raised_by: Optional[Literal["committee", "ERG", "stakeholder", "appellant"]] = None
    resolution: IssueResolution = IssueResolution.unresolved


class CommercialLogic(BaseModel):
    pas_or_commercial_arrangement_referenced: Optional[bool] = None
    pricing_flexibility_appeared_necessary: Optional[bool] = None
    recommendation_only_viable_with_revised_pas: Optional[bool] = None


class TimingLogic(BaseModel):
    uk_launch_date: Optional[str] = None
    nice_decision_date: Optional[str] = None
    months_from_launch_to_decision: Optional[float] = None
    access_delayed: Optional[bool] = None


class SourceTraceability(BaseModel):
    """Each populated field should trace back to source document type + date."""
    source_document_title: str
    source_document_type: Optional[str] = None
    publication_date: Optional[str] = None
    local_path: Optional[str] = None


class AnalogueProfile(BaseModel):
    """Logic 1 output object."""
    analogue_identity: AnalogueIdentity
    process_metadata: ProcessMetadata
    final_access_outcome: FinalAccessOutcome
    reimbursed_population: ReimbursedPopulation
    comparator_logic: ComparatorLogic
    clinical_logic: ClinicalEvidenceLogic
    economic_logic: EconomicEvidenceLogic
    committee_concerns: List[CommitteeConcern] = Field(default_factory=list)
    commercial_logic: CommercialLogic
    timing_logic: TimingLogic
    source_traceability: List[SourceTraceability] = Field(default_factory=list)
    public_vs_non_public_flags: Dict[str, str] = Field(
        default_factory=dict,
        description="Map of field name -> 'public' | 'non_public' (esp. ICER, PAS).",
    )


class AnalyzeOneAnalogueInput(BaseModel):
    analogue_name: str
    guidance_code: Optional[str] = None
    documents: List[DownloadedDocument]
    chunk_chars: int = 60000


class AnalyzeOneAnalogueOutput(BaseModel):
    profile: AnalogueProfile


# =====================================================================
# Skill 3 — Compare all analogues (Logic 2)
# =====================================================================

class CompareAllAnaloguesInput(BaseModel):
    product_a: ProductA
    profiles: List[AnalogueProfile]


class AnalogueComparisonRow(BaseModel):
    analogue_name: str
    classification: PrecedentClass
    nice_outcome: NICEOutcome
    population_restriction: Optional[str] = None
    comparator_pattern: Optional[str] = None
    evidence_maturity: Optional[str] = None
    key_committee_concern: Optional[str] = None
    commercial_pattern: Optional[str] = None
    timing_pattern: Optional[str] = None
    appeal_process_pattern: Optional[str] = None
    predictive_relevance_rank: Optional[int] = None
    role_in_later_prediction: Optional[str] = None


class DecisionPatternSummary(BaseModel):
    """Synthesised pattern across the set."""
    most_common_access_route_competitors: Optional[str] = None
    most_common_access_route_analogues: Optional[str] = None
    most_common_reason_for_restriction: Optional[str] = None
    typical_evidence_maturity_at_positive_decision: Optional[str] = None
    typical_use_of_pas: Optional[str] = None
    typical_launch_to_decision_months: Optional[float] = None
    appeal_frequency: Optional[str] = None
    downside_indicators: List[str] = Field(default_factory=list)
    base_indicators: List[str] = Field(default_factory=list)
    upside_indicators: List[str] = Field(default_factory=list)


class CompareAllAnaloguesOutput(BaseModel):
    competitor_set: List[AnalogueComparisonRow]
    analogue_set: List[AnalogueComparisonRow]
    decision_pattern_summary: DecisionPatternSummary
    narrative: Optional[str] = None


# =====================================================================
# Skill 4 — Predict on current evidence (Logic 3)
# =====================================================================

class ProductACurrentEvidence(BaseModel):
    """Inputs from the 'Required inputs' table of Logic 3."""
    phase: Optional[str] = None
    trial_design: Optional[str] = None
    endpoints: List[str] = Field(default_factory=list)
    comparator: Optional[str] = None
    follow_up: Optional[str] = None
    safety_profile: Optional[str] = None
    qol_availability: Optional[bool] = None
    additional_notes: Optional[str] = None


class CommercialAssumptions(BaseModel):
    assumed_launch_setting: Optional[str] = None
    payer_geography: str = "England and Wales / NICE"
    intended_positioning: Optional[Literal["broad", "narrow"]] = None
    user_supplied_price_assumption: Optional[str] = None


class DomainAssessment(BaseModel):
    domain: str
    assessment: FitLevel
    contribution: Literal["Positive", "Neutral", "Negative"]
    explanation: str


class PriceCorridor(BaseModel):
    label: Literal["Conservative", "Base", "Optimistic", "Target", "Upside"] = "Base"
    evidence_assumption: str
    likely_access_outcome: str
    indicative_corridor: str = Field(
        ..., description="Narrative or numeric range, e.g. '£X-£Y'."
    )
    qualitative_discount_intensity: Optional[Literal["low", "medium", "high", "very_high"]] = None
    corridor_narrative: Optional[str] = None


class PredictCurrentEvidenceInput(BaseModel):
    product_a: ProductA
    current_evidence: ProductACurrentEvidence
    comparison: CompareAllAnaloguesOutput
    commercial_assumptions: CommercialAssumptions = Field(default_factory=CommercialAssumptions)


class PredictCurrentEvidenceOutput(BaseModel):
    predicted_pathway: PredictedPathway
    pathway_confidence: RelevanceLevel
    key_positive_driver: str
    key_limiting_factor: str
    expected_access_pathway_narrative: str
    base_case_rationale: str = Field(
        ..., description="Committee-style explanation of why Product A aligns with relevant precedent set."
    )
    domain_assessments: List[DomainAssessment]
    corridors: List[PriceCorridor] = Field(
        ..., description="Conservative / Base / Optimistic at minimum."
    )
    critical_sensitivities: List[str]
    nice_concerns_identified: List[str] = Field(
        default_factory=list,
        description="Top decision-limiting concerns; consumed by Logic 4.",
    )


# =====================================================================
# Skill 5 — Recommend additional evidence (Logic 4)
# =====================================================================

class EvidenceRecommendation(BaseModel):
    priority: Priority
    evidence_gap: EvidenceGapCategory
    nice_concern_addressed: str
    recommended_action: str
    expected_impact_on_access: str
    expected_impact_on_corridor: str
    feasibility_signal: Literal["pre_launch", "launch_adjacent", "post_launch"] = "pre_launch"
    analogue_support: Optional[str] = Field(
        None, description="Which precedent suggests this evidence mattered in practice."
    )
    primarily_improves: Literal["access_probability", "corridor_ceiling", "both"] = "both"


class RecommendAdditionalEvidenceInput(BaseModel):
    product_a: ProductA
    base_prediction: PredictCurrentEvidenceOutput
    comparison: CompareAllAnaloguesOutput


class RecommendAdditionalEvidenceOutput(BaseModel):
    recommendations: List[EvidenceRecommendation]
    rejected_candidates: List[str] = Field(
        default_factory=list,
        description="Evidence asks that were considered but removed because they would not change pathway/corridor materially.",
    )
    rationale: str


# =====================================================================
# Skill 6 — Predict with additional evidence (Logic 5)
# =====================================================================

class PredictWithAdditionalEvidenceInput(BaseModel):
    base_prediction: PredictCurrentEvidenceOutput
    evidence_recommendations: RecommendAdditionalEvidenceOutput
    comparison: CompareAllAnaloguesOutput
    commercial_assumptions: CommercialAssumptions = Field(default_factory=CommercialAssumptions)


class PredictWithAdditionalEvidenceOutput(BaseModel):
    updated_pathway: PredictedPathway
    pathway_confidence: RelevanceLevel
    expected_access_pathway_narrative: str
    delta_rationale: str = Field(
        ..., description="What concerns were resolved; what concerns remain."
    )
    resolved_concerns: List[str] = Field(default_factory=list)
    remaining_concerns: List[str] = Field(default_factory=list)
    updated_corridors: List[PriceCorridor]
    residual_risk_log: List[str] = Field(default_factory=list)
    most_likely_progression_path: str = Field(
        ...,
        description=(
            "e.g. 'current evidence -> managed access -> reassessment -> "
            "restricted or routine recommendation'"
        ),
    )


# =====================================================================
# End-to-end pipeline output (mirrors the explainable landscape template)
# =====================================================================

class FullAssessmentOutput(BaseModel):
    """The combined output equivalent to the explainable-landscape template."""
    product_a: ProductA
    analogue_identification: AnalogueIdentificationOutput
    nice_retrieval: Optional[NICEHistoryRetrievalOutput] = None
    analogue_profiles: List[AnalogueProfile] = Field(default_factory=list)
    comparison: Optional[CompareAllAnaloguesOutput] = None
    base_case_prediction: Optional[PredictCurrentEvidenceOutput] = None
    evidence_recommendations: Optional[RecommendAdditionalEvidenceOutput] = None
    improved_prediction: Optional[PredictWithAdditionalEvidenceOutput] = None
    assumptions_log: List[str] = Field(default_factory=list)
    uncertainty_log: List[str] = Field(default_factory=list)
    audit_trail: Dict[str, Any] = Field(default_factory=dict)
