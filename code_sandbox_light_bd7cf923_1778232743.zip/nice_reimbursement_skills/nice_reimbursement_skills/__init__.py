"""
NICE Reimbursement Skills
=========================

A Python skill library that distills 7 product-agnostic logics for predicting
the NICE reimbursement potential and price corridor of a pre-launch / pre-NICE
asset (Product A) by benchmarking it against the NICE history of analogue and
competitor products.

The 7 skills (in pipeline order):

    0. AnalogueIdentificationSkill
    1. NICEHistoryRetrievalSkill
    2. AnalyzeOneAnalogueSkill          (Logic 1)
    3. CompareAllAnaloguesSkill         (Logic 2)
    4. PredictCurrentEvidenceSkill      (Logic 3)
    5. RecommendAdditionalEvidenceSkill (Logic 4)
    6. PredictWithAdditionalEvidenceSkill (Logic 5)

Each skill is a subclass of :class:`BaseSkill` and exposes three adapter
methods that make it directly callable from:

    * OpenAI function-calling / Assistants API
    * Anthropic Claude tool use
    * LangChain (StructuredTool)

See README.md for end-to-end usage.
"""

from .base import BaseSkill, SkillRegistry, registry
from .llm_client import LLMClient, OpenAIClient, AnthropicClient

# Skill imports
from .skills.s0_analogue_identification import AnalogueIdentificationSkill
from .skills.s1_nice_history_retrieval import NICEHistoryRetrievalSkill
from .skills.s2_analyze_one_analogue import AnalyzeOneAnalogueSkill
from .skills.s3_compare_all_analogues import CompareAllAnaloguesSkill
from .skills.s4_predict_current_evidence import PredictCurrentEvidenceSkill
from .skills.s5_recommend_additional_evidence import RecommendAdditionalEvidenceSkill
from .skills.s6_predict_with_additional_evidence import PredictWithAdditionalEvidenceSkill

from .orchestrator import ReimbursementAssessmentPipeline

__version__ = "0.1.0"

__all__ = [
    "BaseSkill",
    "SkillRegistry",
    "registry",
    "LLMClient",
    "OpenAIClient",
    "AnthropicClient",
    "AnalogueIdentificationSkill",
    "NICEHistoryRetrievalSkill",
    "AnalyzeOneAnalogueSkill",
    "CompareAllAnaloguesSkill",
    "PredictCurrentEvidenceSkill",
    "RecommendAdditionalEvidenceSkill",
    "PredictWithAdditionalEvidenceSkill",
    "ReimbursementAssessmentPipeline",
]
