"""
Base classes for the NICE reimbursement skill library.

Every skill subclasses :class:`BaseSkill` and declares:
    * name              - unique identifier (snake_case)
    * description       - one-sentence purpose for the LLM tool router
    * input_model       - pydantic model describing the input
    * output_model      - pydantic model describing the output
    * run(input_obj)    - the business logic

Skills are framework-agnostic. The three adapter properties / methods give the
caller a ready-to-use representation for OpenAI, Anthropic, or LangChain:

    skill.openai_tool_schema()      -> dict   (OpenAI function-calling)
    skill.anthropic_tool_schema()   -> dict   (Claude tools)
    skill.as_langchain_tool()       -> StructuredTool (LangChain)

`SkillRegistry` collects skills so an agent can discover and dispatch them.
"""
from __future__ import annotations

import json
import logging
from abc import ABC, abstractmethod
from typing import Any, Dict, Generic, List, Optional, Type, TypeVar

from pydantic import BaseModel, ValidationError

logger = logging.getLogger(__name__)

InputT = TypeVar("InputT", bound=BaseModel)
OutputT = TypeVar("OutputT", bound=BaseModel)


class BaseSkill(ABC, Generic[InputT, OutputT]):
    """Abstract base for every NICE reimbursement skill."""

    #: Unique skill identifier (snake_case).
    name: str = ""
    #: One-sentence description used as the LLM tool description.
    description: str = ""
    #: Pydantic model class for the input.
    input_model: Type[BaseModel] = BaseModel
    #: Pydantic model class for the output.
    output_model: Type[BaseModel] = BaseModel

    def __init__(self, llm_client: Optional["LLMClient"] = None, **kwargs: Any):
        # Late import to avoid a circular import between base.py and llm_client.py
        from .llm_client import LLMClient  # noqa: F401

        self.llm_client = llm_client
        self.config: Dict[str, Any] = kwargs

    # ------------------------------------------------------------------ #
    # Core API                                                           #
    # ------------------------------------------------------------------ #

    @abstractmethod
    def run(self, input_obj: InputT) -> OutputT:
        """Execute the skill on a validated input and return a validated output."""

    def __call__(self, input_data: Any) -> BaseModel:
        """
        Universal entrypoint.

        Accepts:
            * a pydantic instance of `input_model`
            * a dict
            * a JSON string
        Returns a pydantic instance of `output_model`.
        """
        validated = self._coerce_input(input_data)
        try:
            result = self.run(validated)
        except Exception:
            logger.exception("Skill %s failed", self.name)
            raise
        if not isinstance(result, BaseModel):
            # Allow run() to return a dict; coerce to output_model.
            result = self.output_model.model_validate(result)
        return result

    def _coerce_input(self, input_data: Any) -> InputT:
        if isinstance(input_data, self.input_model):
            return input_data  # type: ignore[return-value]
        if isinstance(input_data, BaseModel):
            input_data = input_data.model_dump()
        if isinstance(input_data, str):
            try:
                input_data = json.loads(input_data)
            except json.JSONDecodeError as e:
                raise ValueError(f"Input string is not valid JSON: {e}") from e
        if not isinstance(input_data, dict):
            raise TypeError(
                f"{self.name}: expected dict / JSON / {self.input_model.__name__}, "
                f"got {type(input_data).__name__}"
            )
        try:
            return self.input_model.model_validate(input_data)  # type: ignore[return-value]
        except ValidationError as e:
            raise ValueError(f"{self.name}: input validation failed:\n{e}") from e

    # ------------------------------------------------------------------ #
    # Schema helpers                                                     #
    # ------------------------------------------------------------------ #

    def input_json_schema(self) -> Dict[str, Any]:
        return self.input_model.model_json_schema()

    def output_json_schema(self) -> Dict[str, Any]:
        return self.output_model.model_json_schema()

    # ------------------------------------------------------------------ #
    # Adapter 1: OpenAI function-calling / tools                         #
    # ------------------------------------------------------------------ #

    def openai_tool_schema(self) -> Dict[str, Any]:
        """
        Returns a dict ready to drop into the `tools=[...]` parameter of
        `client.chat.completions.create` (OpenAI Python SDK >= 1.0).
        """
        params = self.input_json_schema()
        # OpenAI requires top-level type=object; pydantic provides that already.
        # Strip "$defs" duplicates is allowed but not required.
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": params,
            },
        }

    def invoke_from_openai_tool_call(self, tool_call: Any) -> str:
        """
        Convenience: take an OpenAI tool_call object (or a dict with `arguments`
        as a JSON string) and return the JSON-encoded output.
        """
        if hasattr(tool_call, "function"):
            args = tool_call.function.arguments
        elif isinstance(tool_call, dict) and "function" in tool_call:
            args = tool_call["function"]["arguments"]
        else:
            args = tool_call
        result = self(args)
        return result.model_dump_json()

    # ------------------------------------------------------------------ #
    # Adapter 2: Anthropic Claude tool use                               #
    # ------------------------------------------------------------------ #

    def anthropic_tool_schema(self) -> Dict[str, Any]:
        """Returns a dict suitable for the `tools=[...]` arg of Anthropic Messages API."""
        return {
            "name": self.name,
            "description": self.description,
            "input_schema": self.input_json_schema(),
        }

    def invoke_from_anthropic_tool_use(self, tool_use_block: Any) -> Dict[str, Any]:
        """Take a tool_use block from Claude and return a dict result."""
        if hasattr(tool_use_block, "input"):
            args = tool_use_block.input
        elif isinstance(tool_use_block, dict):
            args = tool_use_block.get("input", tool_use_block)
        else:
            args = tool_use_block
        return self(args).model_dump()

    # ------------------------------------------------------------------ #
    # Adapter 3: LangChain                                               #
    # ------------------------------------------------------------------ #

    def as_langchain_tool(self):
        """
        Returns a `langchain_core.tools.StructuredTool` that wraps this skill.

        Requires `langchain-core` to be installed.
        """
        try:
            from langchain_core.tools import StructuredTool
        except ImportError as e:  # pragma: no cover
            raise ImportError(
                "LangChain support requires 'langchain-core'. "
                "Install with: pip install langchain-core"
            ) from e

        skill = self

        def _runner(**kwargs: Any) -> Dict[str, Any]:
            return skill(kwargs).model_dump()

        return StructuredTool.from_function(
            func=_runner,
            name=self.name,
            description=self.description,
            args_schema=self.input_model,
        )


# ---------------------------------------------------------------------- #
# Skill registry                                                         #
# ---------------------------------------------------------------------- #

class SkillRegistry:
    """In-memory registry of skills. Lets agents discover & dispatch by name."""

    def __init__(self) -> None:
        self._skills: Dict[str, BaseSkill] = {}

    def register(self, skill: BaseSkill) -> BaseSkill:
        if not skill.name:
            raise ValueError("Skill is missing a `name`.")
        if skill.name in self._skills:
            logger.warning("Overwriting registered skill %s", skill.name)
        self._skills[skill.name] = skill
        return skill

    def get(self, name: str) -> BaseSkill:
        if name not in self._skills:
            raise KeyError(f"Skill '{name}' is not registered. "
                           f"Known skills: {list(self._skills)}")
        return self._skills[name]

    def list(self) -> List[str]:
        return list(self._skills)

    def dispatch(self, name: str, payload: Any) -> BaseModel:
        return self.get(name)(payload)

    # Bulk schema exports

    def openai_tools(self) -> List[Dict[str, Any]]:
        return [s.openai_tool_schema() for s in self._skills.values()]

    def anthropic_tools(self) -> List[Dict[str, Any]]:
        return [s.anthropic_tool_schema() for s in self._skills.values()]

    def langchain_tools(self) -> List[Any]:
        return [s.as_langchain_tool() for s in self._skills.values()]


#: Default global registry. Skills register themselves into this on import.
registry = SkillRegistry()
