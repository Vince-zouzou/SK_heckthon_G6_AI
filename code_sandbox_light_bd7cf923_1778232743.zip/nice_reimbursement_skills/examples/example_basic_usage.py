"""
Example 1: Run the full end-to-end pipeline from Python.

    export OPENAI_API_KEY=sk-...
    python examples/example_basic_usage.py
"""
from __future__ import annotations

import json
from pathlib import Path

from nice_reimbursement_skills import (
    OpenAIClient,
    ReimbursementAssessmentPipeline,
)
from nice_reimbursement_skills.models import (
    CommercialAssumptions,
    ProductA,
    ProductACurrentEvidence,
)


def main():
    payload = json.loads(Path("examples/product_a_example.json").read_text())
    product_a = ProductA.model_validate(payload["product_a"])
    current_evidence = ProductACurrentEvidence.model_validate(payload["current_evidence"])
    commercial = CommercialAssumptions.model_validate(payload["commercial_assumptions"])

    client = OpenAIClient(model="gpt-4o-mini")  # or "gpt-4o", "gpt-4.1", ...
    pipeline = ReimbursementAssessmentPipeline(
        llm_client=client,
        download_dir="./nice_documents",
        max_documents_per_analogue=15,
    )

    result = pipeline.run(
        product_a=product_a,
        current_evidence=current_evidence,
        commercial_assumptions=commercial,
        max_competitors=4,
        max_analogues=6,
    )

    Path("full_assessment.json").write_text(
        result.model_dump_json(indent=2), encoding="utf-8"
    )
    print("Saved full_assessment.json")
    print("Predicted base-case pathway:",
          result.base_case_prediction.predicted_pathway if result.base_case_prediction else "N/A")


if __name__ == "__main__":
    main()
