"""
Example 4: Use the skills as LangChain StructuredTools.

    pip install langchain-core langchain-openai
    export OPENAI_API_KEY=sk-...
    python examples/example_langchain.py
"""
from __future__ import annotations

from nice_reimbursement_skills import OpenAIClient, registry
from nice_reimbursement_skills.skills import (
    AnalogueIdentificationSkill,
    CompareAllAnaloguesSkill,
    PredictCurrentEvidenceSkill,
    PredictWithAdditionalEvidenceSkill,
    RecommendAdditionalEvidenceSkill,
)


def main():
    # Build an LLM-bound version of each LLM-using skill.
    llm = OpenAIClient(model="gpt-4o-mini")
    bound_skills = [
        AnalogueIdentificationSkill(llm_client=llm),
        CompareAllAnaloguesSkill(llm_client=llm),
        PredictCurrentEvidenceSkill(llm_client=llm),
        RecommendAdditionalEvidenceSkill(llm_client=llm),
        PredictWithAdditionalEvidenceSkill(llm_client=llm),
    ]
    # NICE retrieval skill needs no LLM.
    bound_skills.append(registry.get("nice_history_retrieval"))

    lc_tools = [s.as_langchain_tool() for s in bound_skills]
    print(f"Built {len(lc_tools)} LangChain tools.")
    for t in lc_tools:
        print(f"  - {t.name}: {t.description[:80]}")

    # The tools can now be passed to any LangChain agent / runnable that
    # accepts `tools=...`. See https://python.langchain.com/docs/modules/agents/.


if __name__ == "__main__":
    main()
