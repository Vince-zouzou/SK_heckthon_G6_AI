"""
Example 3: Register the 7 skills as Anthropic Claude tools.

    export ANTHROPIC_API_KEY=sk-ant-...
    python examples/example_claude_tool_use.py
"""
from __future__ import annotations

import anthropic

from nice_reimbursement_skills import registry


def main():
    tools = registry.anthropic_tools()
    print(f"Registered {len(tools)} skills as Claude tools.")

    client = anthropic.Anthropic()
    resp = client.messages.create(
        model="claude-3-5-sonnet-20241022",
        max_tokens=2048,
        tools=tools,
        messages=[{"role": "user", "content": (
            "Identify analogues for Product A (oral EGFR exon 20 insertion TKI, "
            "2L NSCLC) using the analogue_identification tool."
        )}],
    )

    for block in resp.content:
        if getattr(block, "type", None) == "tool_use":
            skill = registry.get(block.name)
            try:
                result = skill.invoke_from_anthropic_tool_use(block)
                print(f"\n>>> Tool {block.name} returned:")
                import json
                print(json.dumps(result, indent=2, default=str))
            except RuntimeError as e:
                print(f"(Skill {block.name} requires an LLMClient: {e})")


if __name__ == "__main__":
    main()
