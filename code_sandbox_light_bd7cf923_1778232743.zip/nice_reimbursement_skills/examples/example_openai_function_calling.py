"""
Example 2: Register the 7 skills as OpenAI function-calling tools.

This shows how an agent loop on top of OpenAI can dispatch to skills by name.

    export OPENAI_API_KEY=sk-...
    python examples/example_openai_function_calling.py
"""
from __future__ import annotations

import json

from openai import OpenAI

from nice_reimbursement_skills import registry


def main():
    tools = registry.openai_tools()
    print(f"Registered {len(tools)} skills as OpenAI tools.")
    for t in tools:
        print(f"  - {t['function']['name']}")

    client = OpenAI()
    messages = [
        {"role": "system", "content": "You are a UK market-access analyst."},
        {"role": "user", "content": (
            "Identify analogues for Product A: an oral, EGFR exon 20 insertion-"
            "selective TKI for 2L NSCLC. Use the analogue_identification tool."
        )},
    ]

    resp = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=messages,
        tools=tools,
        tool_choice="auto",
    )

    msg = resp.choices[0].message
    if not msg.tool_calls:
        print("Model did not call any tool. Reply:", msg.content)
        return

    for call in msg.tool_calls:
        skill = registry.get(call.function.name)
        # NOTE: Skills bound to LLM reasoning need a client. The default
        # registry instances have no llm_client. For a real loop, instantiate
        # the skill with a client (see example_basic_usage.py).
        try:
            output_json = skill.invoke_from_openai_tool_call(call)
            print(f"\n>>> Tool {call.function.name} returned:")
            print(output_json)
        except RuntimeError as e:
            print(f"(Skill {call.function.name} requires an LLMClient: {e})")


if __name__ == "__main__":
    main()
