"""Install with: pip install -e ."""
from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="nice_reimbursement_skills",
    version="0.1.0",
    description="Skill library for NICE reimbursement potential assessment (analogue identification, NICE doc retrieval, NICE-style prediction).",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    python_requires=">=3.10",
    install_requires=[
        "pydantic>=2.5.0",
        "requests>=2.31.0",
        "beautifulsoup4>=4.12.0",
        "lxml>=4.9.0",
        "pypdf>=4.0.0",
        "pdfminer.six>=20231228",
        "tenacity>=8.2.0",
        "python-slugify>=8.0.0",
        "tqdm>=4.66.0",
    ],
    extras_require={
        "openai": ["openai>=1.40.0"],
        "anthropic": ["anthropic>=0.34.0"],
        "langchain": ["langchain-core>=0.2.0"],
        "all": [
            "openai>=1.40.0",
            "anthropic>=0.34.0",
            "langchain-core>=0.2.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "nice-skills=nice_reimbursement_skills.cli:main",
        ],
    },
)
