# NICE Reimbursement Skills

A Python skill library that distills 7 product-agnostic logics for predicting
the **NICE reimbursement potential and price corridor** of a pre-launch /
pre-NICE asset by benchmarking it against the NICE history of analogue and
competitor products.

Every skill is callable directly from:

| Framework | How |
|---|---|
| **OpenAI function-calling / Assistants API** | `registry.openai_tools()` |
| **Anthropic Claude tool use** | `registry.anthropic_tools()` |
| **LangChain** | `skill.as_langchain_tool()` |
| **Plain Python** | `skill(input_dict)` |

The library is an exact translation of 8 source documents into Python:

- `analogue_identification_recommendation_fixed.txt` → Skill 0
- `nice_history_page_logic.txt` → Skill 1
- `logic_1_analyze_one_analogue.txt` → Skill 2
- `logic_2_compare_all_analogues.txt` → Skill 3
- `logic_3_predict_current_evidence.txt` → Skill 4
- `logic_4_recommend_additional_evidence.txt` → Skill 5
- `logic_5_predict_with_additional_evidence.txt` → Skill 6
- `reimbursement_potential_output_explainable_landscape.txt` → output schema (`FullAssessmentOutput`)

---

## Pipeline

```
                 ┌────────────────────────────────────┐
                 │  ProductA + current evidence input │
                 └─────────────────┬──────────────────┘
                                   ▼
   Skill 0  AnalogueIdentificationSkill        ← LLM
                                   │
                ─── MANDATORY USER CONFIRMATION GATE ───
                                   ▼
   Skill 1  NICEHistoryRetrievalSkill           ← deterministic scraper
                                   ▼
   Skill 2  AnalyzeOneAnalogueSkill  (× N)      ← LLM + PDF parsing
                                   ▼
   Skill 3  CompareAllAnaloguesSkill            ← LLM
                                   ▼
   Skill 4  PredictCurrentEvidenceSkill         ← LLM
                                   ▼
   Skill 5  RecommendAdditionalEvidenceSkill    ← LLM
                                   ▼
   Skill 6  PredictWithAdditionalEvidenceSkill  ← LLM
                                   ▼
                       FullAssessmentOutput
```

---

## Install

```bash
git clone <this-repo>
cd nice_reimbursement_skills
pip install -e .[all]      # installs openai, anthropic, langchain-core
# or:
pip install -r requirements.txt
```

Set credentials for whichever provider you use:

```bash
export OPENAI_API_KEY=sk-...
# or
export ANTHROPIC_API_KEY=sk-ant-...
```

---

## Quick start

### 1) End-to-end pipeline (Python)

```python
from nice_reimbursement_skills import (
    OpenAIClient,
    ReimbursementAssessmentPipeline,
)
from nice_reimbursement_skills.models import (
    ProductA, ProductACurrentEvidence, CommercialAssumptions,
)

product_a = ProductA(
    name="Product A",
    indication="Advanced NSCLC with EGFR exon 20 insertion",
    line_of_therapy="Second-line, post-platinum",
    target_population="Adults with locally advanced/metastatic NSCLC...",
    biomarker_or_subgroup="EGFR exon 20 insertion",
    route_of_administration="Oral, self-administered",
    rarity_context="orphan",
    development_stage="Phase II results available; not yet launched",
)

current_evidence = ProductACurrentEvidence(
    phase="Phase II",
    trial_design="Single-arm open-label",
    endpoints=["ORR", "DoR", "PFS"],
    qol_availability=False,
)

pipeline = ReimbursementAssessmentPipeline(llm_client=OpenAIClient(model="gpt-4o-mini"))
result = pipeline.run(product_a=product_a, current_evidence=current_evidence)

print(result.base_case_prediction.predicted_pathway)
print(result.improved_prediction.updated_pathway)
```

### 2) End-to-end pipeline (CLI)

```bash
nice-skills run \
  --input examples/product_a_example.json \
  --output full_assessment.json \
  --provider openai --model gpt-4o-mini
```

### 3) OpenAI function-calling

```python
from openai import OpenAI
from nice_reimbursement_skills import registry, OpenAIClient
from nice_reimbursement_skills.skills import AnalogueIdentificationSkill

llm = OpenAIClient(model="gpt-4o-mini")
analogue_skill = AnalogueIdentificationSkill(llm_client=llm)

client = OpenAI()
resp = client.chat.completions.create(
    model="gpt-4o-mini",
    messages=[...],
    tools=[analogue_skill.openai_tool_schema()],
)

for tc in resp.choices[0].message.tool_calls or []:
    json_result = analogue_skill.invoke_from_openai_tool_call(tc)
```

### 4) Claude tool use

```python
import anthropic
from nice_reimbursement_skills import AnthropicClient
from nice_reimbursement_skills.skills import AnalogueIdentificationSkill

skill = AnalogueIdentificationSkill(llm_client=AnthropicClient())
client = anthropic.Anthropic()
resp = client.messages.create(
    model="claude-3-5-sonnet-20241022",
    max_tokens=2048,
    tools=[skill.anthropic_tool_schema()],
    messages=[{"role": "user", "content": "..."}],
)

for block in resp.content:
    if getattr(block, "type", None) == "tool_use" and block.name == skill.name:
        result = skill.invoke_from_anthropic_tool_use(block)
```

### 5) LangChain

```python
from nice_reimbursement_skills import OpenAIClient
from nice_reimbursement_skills.skills import AnalogueIdentificationSkill

skill = AnalogueIdentificationSkill(llm_client=OpenAIClient())
lc_tool = skill.as_langchain_tool()

# Pass `lc_tool` to any LangChain agent that accepts `tools=...`.
```

---

## Skill catalogue

| Skill | Purpose | LLM? |
|---|---|---|
| `analogue_identification` | Produce competitor + analogue shortlist (competitor-first); stops with user-confirmation gate. | ✅ |
| `nice_history_retrieval` | Resolve NICE guidance record, derive `/guidance/{code}/history`, parse documents, download PDFs. | ❌ scraper |
| `analyze_one_analogue` | Logic 1: extract structured analogue profile from all NICE PDFs of one product. | ✅ |
| `compare_all_analogues` | Logic 2: cross-analogue comparison + decision-pattern synthesis. | ✅ |
| `predict_current_evidence` | Logic 3: base-case NICE pathway + Conservative/Base/Optimistic price corridors. | ✅ |
| `recommend_additional_evidence` | Logic 4: minimum decision-relevant evidence package to lift access/corridor. | ✅ |
| `predict_with_additional_evidence` | Logic 5: delta assessment after evidence improvements (updated pathway + corridors). | ✅ |

---

## Architecture

```
nice_reimbursement_skills/
├── nice_reimbursement_skills/
│   ├── __init__.py                 # public API
│   ├── base.py                     # BaseSkill + SkillRegistry + 3 adapters
│   ├── llm_client.py               # OpenAIClient, AnthropicClient, EchoClient
│   ├── models.py                   # All Pydantic models (input + output)
│   ├── prompts.py                  # Prompt templates per LLM-using skill
│   ├── nice_scraper.py             # NICE search / overview / history / PDF
│   ├── pdf_utils.py                # PDF text extraction (pypdf + pdfminer fallback)
│   ├── orchestrator.py             # End-to-end pipeline class
│   ├── cli.py                      # `nice-skills` command
│   └── skills/
│       ├── s0_analogue_identification.py
│       ├── s1_nice_history_retrieval.py
│       ├── s2_analyze_one_analogue.py
│       ├── s3_compare_all_analogues.py
│       ├── s4_predict_current_evidence.py
│       ├── s5_recommend_additional_evidence.py
│       └── s6_predict_with_additional_evidence.py
├── examples/
│   ├── product_a_example.json
│   ├── example_basic_usage.py
│   ├── example_openai_function_calling.py
│   ├── example_claude_tool_use.py
│   └── example_langchain.py
├── requirements.txt
├── setup.py
└── README.md
```

### Why `BaseSkill` + 3 adapters?

Each skill defines:

- `name`, `description` (used by the LLM tool router)
- `input_model`, `output_model` (Pydantic — drives JSON schema, validation, docs)
- `run(input_obj) -> output_obj` (the business logic)

The base class then automatically generates:

| Method | Returns |
|---|---|
| `openai_tool_schema()` | `{type: "function", function: {name, description, parameters}}` |
| `anthropic_tool_schema()` | `{name, description, input_schema}` |
| `as_langchain_tool()` | `langchain_core.tools.StructuredTool` |
| `__call__(payload)` | accepts dict / JSON / pydantic model — returns validated output |

A global `SkillRegistry` (importable as `registry`) lets agents dispatch by name.

---

## User-confirmation gate (important)

The source workflow MANDATES a pause after the analogue list is produced.
The orchestrator enforces this with a callback:

```python
def my_confirmation(proposal):
    # show `proposal.proposed_analogues` to the user, let them edit / replace,
    # then return the confirmed list of ProposedAnalogue items.
    return [p for p in proposal.proposed_analogues if user_says_yes(p)]

pipeline.run(..., on_confirm=my_confirmation)
```

The default is `auto_confirm_all` which keeps every analogue with
`inclusion_status_default == "included"` — convenient for tests / CI but
**not** what production should use.

---

## Output structure

`FullAssessmentOutput` mirrors the explainable-landscape template:

| Field | Source view |
|---|---|
| `analogue_identification` | Output 1 + View 1A + View 1B |
| `nice_retrieval` | Steps 1–8 of NICE history logic |
| `analogue_profiles` | Logic 1 output × N analogues |
| `comparison` | Output 2 + View 2A + View 2B |
| `base_case_prediction` | Output 3 + Output 4 + Output 6 (current-evidence corridor) |
| `evidence_recommendations` | Output 5 |
| `improved_prediction` | Output 6 (corridor with proposed evidence) |
| `audit_trail`, `assumptions_log`, `uncertainty_log` | Cross-cutting transparency outputs |

---

## Roadmap

- [ ] Vector-index NICE PDFs for retrieval-augmented Logic 1 (handles 200+ page committee papers without re-extracting per skill)
- [ ] Switchable structured-output mode (`response_format=json_schema`) for OpenAI / Claude
- [ ] Async pipeline (`asyncio.gather` over per-analogue Logic 1 calls)
- [ ] Test fixtures with cached NICE pages for offline CI
- [ ] Streamlit / Gradio UI for the user-confirmation gate

---

## License

MIT (see LICENSE).
