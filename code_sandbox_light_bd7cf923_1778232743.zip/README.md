# NICE Reimbursement Skills — Project Root

This project contains a Python skill library that converts 7 product-agnostic
NICE reimbursement assessment logics into AI/ML-callable skills (compatible
with OpenAI function-calling, Anthropic Claude tools, and LangChain).

## What's in this project

```
.
├── _source_docs/                       # original .docx + .txt source documents
├── nice_reimbursement_skills/          # the Python skill library
│   ├── nice_reimbursement_skills/      # package code
│   ├── examples/                       # 4 runnable examples
│   ├── README.md                       # full library documentation
│   ├── requirements.txt
│   ├── setup.py
│   └── LICENSE
└── README.md                           # (this file)
```

## Where to start

➡️ Open **`nice_reimbursement_skills/README.md`** for the full library docs,
quick-start, architecture, and skill catalogue.

## Completed features

- ✅ All 7 skills implemented end-to-end (analogue ID, NICE retrieval, Logic 1–5)
- ✅ Pydantic input/output models for every skill (controlled vocabularies for
  NICE outcomes, evidence gaps, precedent classes, etc.)
- ✅ Three framework adapters per skill (OpenAI, Anthropic, LangChain)
- ✅ Shared `SkillRegistry` for agent dispatch
- ✅ Deterministic NICE scraper (search → overview → history → PDF download)
  with the 4 fallback rules from the source doc
- ✅ PDF text extraction with `pypdf` + `pdfminer.six` fallback for
  layout-heavy committee documents
- ✅ Multi-chunk + merge logic for very long NICE document sets in Logic 1
- ✅ End-to-end orchestrator with mandatory user-confirmation gate
- ✅ `nice-skills` CLI (`run`, `schemas`, `list`)
- ✅ Four runnable examples for the four invocation paths

## Not yet implemented (roadmap)

- ⬜ Vector-index NICE PDFs for retrieval-augmented Logic 1
- ⬜ Native structured-output mode (`response_format=json_schema`)
- ⬜ Async pipeline over per-analogue Logic 1 calls
- ⬜ Cached NICE-page fixtures for offline CI
- ⬜ Streamlit/Gradio UI for the user-confirmation gate

## Recommended next steps

1. `cd nice_reimbursement_skills && pip install -e .[all]`
2. `export OPENAI_API_KEY=...` (or `ANTHROPIC_API_KEY=...`)
3. Run `python examples/example_basic_usage.py` — full pipeline on the
   sample EGFR exon 20 NSCLC product.
4. Replace `examples/product_a_example.json` with your real asset.
5. For production, swap `auto_confirm_all` in
   `ReimbursementAssessmentPipeline.run(...)` with a real UI callback that
   shows the analogue list to the user and returns their confirmed/edited set.
